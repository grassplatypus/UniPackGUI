﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dotLEDEdit
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.LEDboard = New System.Windows.Forms.TableLayoutPanel()
        Me.uni1_1 = New System.Windows.Forms.Button()
        Me.uni1_2 = New System.Windows.Forms.Button()
        Me.uni1_3 = New System.Windows.Forms.Button()
        Me.uni1_4 = New System.Windows.Forms.Button()
        Me.uni1_5 = New System.Windows.Forms.Button()
        Me.uni1_6 = New System.Windows.Forms.Button()
        Me.uni1_7 = New System.Windows.Forms.Button()
        Me.uni1_8 = New System.Windows.Forms.Button()
        Me.uni2_1 = New System.Windows.Forms.Button()
        Me.uni2_2 = New System.Windows.Forms.Button()
        Me.uni2_3 = New System.Windows.Forms.Button()
        Me.uni2_4 = New System.Windows.Forms.Button()
        Me.uni2_5 = New System.Windows.Forms.Button()
        Me.uni2_6 = New System.Windows.Forms.Button()
        Me.uni2_7 = New System.Windows.Forms.Button()
        Me.uni2_8 = New System.Windows.Forms.Button()
        Me.uni3_1 = New System.Windows.Forms.Button()
        Me.uni3_2 = New System.Windows.Forms.Button()
        Me.uni3_3 = New System.Windows.Forms.Button()
        Me.uni3_4 = New System.Windows.Forms.Button()
        Me.uni3_5 = New System.Windows.Forms.Button()
        Me.uni3_6 = New System.Windows.Forms.Button()
        Me.uni3_7 = New System.Windows.Forms.Button()
        Me.uni3_8 = New System.Windows.Forms.Button()
        Me.uni4_1 = New System.Windows.Forms.Button()
        Me.uni4_2 = New System.Windows.Forms.Button()
        Me.uni4_3 = New System.Windows.Forms.Button()
        Me.uni4_4 = New System.Windows.Forms.Button()
        Me.uni4_5 = New System.Windows.Forms.Button()
        Me.uni4_6 = New System.Windows.Forms.Button()
        Me.uni4_7 = New System.Windows.Forms.Button()
        Me.uni4_8 = New System.Windows.Forms.Button()
        Me.uni5_1 = New System.Windows.Forms.Button()
        Me.uni5_2 = New System.Windows.Forms.Button()
        Me.uni5_3 = New System.Windows.Forms.Button()
        Me.uni5_4 = New System.Windows.Forms.Button()
        Me.uni5_5 = New System.Windows.Forms.Button()
        Me.uni5_6 = New System.Windows.Forms.Button()
        Me.uni5_7 = New System.Windows.Forms.Button()
        Me.uni5_8 = New System.Windows.Forms.Button()
        Me.uni6_1 = New System.Windows.Forms.Button()
        Me.uni6_2 = New System.Windows.Forms.Button()
        Me.uni6_3 = New System.Windows.Forms.Button()
        Me.uni6_4 = New System.Windows.Forms.Button()
        Me.uni6_5 = New System.Windows.Forms.Button()
        Me.uni6_6 = New System.Windows.Forms.Button()
        Me.uni6_7 = New System.Windows.Forms.Button()
        Me.uni6_8 = New System.Windows.Forms.Button()
        Me.uni7_1 = New System.Windows.Forms.Button()
        Me.uni7_2 = New System.Windows.Forms.Button()
        Me.uni7_3 = New System.Windows.Forms.Button()
        Me.uni7_4 = New System.Windows.Forms.Button()
        Me.uni7_5 = New System.Windows.Forms.Button()
        Me.uni7_6 = New System.Windows.Forms.Button()
        Me.uni7_7 = New System.Windows.Forms.Button()
        Me.uni7_8 = New System.Windows.Forms.Button()
        Me.uni8_1 = New System.Windows.Forms.Button()
        Me.uni8_2 = New System.Windows.Forms.Button()
        Me.uni8_3 = New System.Windows.Forms.Button()
        Me.uni8_4 = New System.Windows.Forms.Button()
        Me.uni8_5 = New System.Windows.Forms.Button()
        Me.uni8_6 = New System.Windows.Forms.Button()
        Me.uni8_7 = New System.Windows.Forms.Button()
        Me.uni8_8 = New System.Windows.Forms.Button()
        Me.imgThumb = New System.Windows.Forms.ImageList(Me.components)
        Me.colorPicker = New System.Windows.Forms.ColorDialog()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.listLEDs = New System.Windows.Forms.ListBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.listorder = New System.Windows.Forms.ListBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripComboBox1 = New System.Windows.Forms.ToolStripComboBox()
        Me.LEDboard.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LEDboard
        '
        Me.LEDboard.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.LEDboard.BackColor = System.Drawing.Color.LightGray
        Me.LEDboard.ColumnCount = 8
        Me.LEDboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.Controls.Add(Me.uni1_1, 0, 0)
        Me.LEDboard.Controls.Add(Me.uni1_2, 1, 0)
        Me.LEDboard.Controls.Add(Me.uni1_3, 2, 0)
        Me.LEDboard.Controls.Add(Me.uni1_4, 3, 0)
        Me.LEDboard.Controls.Add(Me.uni1_5, 4, 0)
        Me.LEDboard.Controls.Add(Me.uni1_6, 5, 0)
        Me.LEDboard.Controls.Add(Me.uni1_7, 6, 0)
        Me.LEDboard.Controls.Add(Me.uni1_8, 7, 0)
        Me.LEDboard.Controls.Add(Me.uni2_1, 0, 1)
        Me.LEDboard.Controls.Add(Me.uni2_2, 1, 1)
        Me.LEDboard.Controls.Add(Me.uni2_3, 2, 1)
        Me.LEDboard.Controls.Add(Me.uni2_4, 3, 1)
        Me.LEDboard.Controls.Add(Me.uni2_5, 4, 1)
        Me.LEDboard.Controls.Add(Me.uni2_6, 5, 1)
        Me.LEDboard.Controls.Add(Me.uni2_7, 6, 1)
        Me.LEDboard.Controls.Add(Me.uni2_8, 7, 1)
        Me.LEDboard.Controls.Add(Me.uni3_1, 0, 2)
        Me.LEDboard.Controls.Add(Me.uni3_2, 1, 2)
        Me.LEDboard.Controls.Add(Me.uni3_3, 2, 2)
        Me.LEDboard.Controls.Add(Me.uni3_4, 3, 2)
        Me.LEDboard.Controls.Add(Me.uni3_5, 4, 2)
        Me.LEDboard.Controls.Add(Me.uni3_6, 5, 2)
        Me.LEDboard.Controls.Add(Me.uni3_7, 6, 2)
        Me.LEDboard.Controls.Add(Me.uni3_8, 7, 2)
        Me.LEDboard.Controls.Add(Me.uni4_1, 0, 3)
        Me.LEDboard.Controls.Add(Me.uni4_2, 1, 3)
        Me.LEDboard.Controls.Add(Me.uni4_3, 2, 3)
        Me.LEDboard.Controls.Add(Me.uni4_4, 3, 3)
        Me.LEDboard.Controls.Add(Me.uni4_5, 4, 3)
        Me.LEDboard.Controls.Add(Me.uni4_6, 5, 3)
        Me.LEDboard.Controls.Add(Me.uni4_7, 6, 3)
        Me.LEDboard.Controls.Add(Me.uni4_8, 7, 3)
        Me.LEDboard.Controls.Add(Me.uni5_1, 0, 4)
        Me.LEDboard.Controls.Add(Me.uni5_2, 1, 4)
        Me.LEDboard.Controls.Add(Me.uni5_3, 2, 4)
        Me.LEDboard.Controls.Add(Me.uni5_4, 3, 4)
        Me.LEDboard.Controls.Add(Me.uni5_5, 4, 4)
        Me.LEDboard.Controls.Add(Me.uni5_6, 5, 4)
        Me.LEDboard.Controls.Add(Me.uni5_7, 6, 4)
        Me.LEDboard.Controls.Add(Me.uni5_8, 7, 4)
        Me.LEDboard.Controls.Add(Me.uni6_1, 0, 5)
        Me.LEDboard.Controls.Add(Me.uni6_2, 1, 5)
        Me.LEDboard.Controls.Add(Me.uni6_3, 2, 5)
        Me.LEDboard.Controls.Add(Me.uni6_4, 3, 5)
        Me.LEDboard.Controls.Add(Me.uni6_5, 4, 5)
        Me.LEDboard.Controls.Add(Me.uni6_6, 5, 5)
        Me.LEDboard.Controls.Add(Me.uni6_7, 6, 5)
        Me.LEDboard.Controls.Add(Me.uni6_8, 7, 5)
        Me.LEDboard.Controls.Add(Me.uni7_1, 0, 6)
        Me.LEDboard.Controls.Add(Me.uni7_2, 1, 6)
        Me.LEDboard.Controls.Add(Me.uni7_3, 2, 6)
        Me.LEDboard.Controls.Add(Me.uni7_4, 3, 6)
        Me.LEDboard.Controls.Add(Me.uni7_5, 4, 6)
        Me.LEDboard.Controls.Add(Me.uni7_6, 5, 6)
        Me.LEDboard.Controls.Add(Me.uni7_7, 6, 6)
        Me.LEDboard.Controls.Add(Me.uni7_8, 7, 6)
        Me.LEDboard.Controls.Add(Me.uni8_1, 0, 7)
        Me.LEDboard.Controls.Add(Me.uni8_2, 1, 7)
        Me.LEDboard.Controls.Add(Me.uni8_3, 2, 7)
        Me.LEDboard.Controls.Add(Me.uni8_4, 3, 7)
        Me.LEDboard.Controls.Add(Me.uni8_5, 4, 7)
        Me.LEDboard.Controls.Add(Me.uni8_6, 5, 7)
        Me.LEDboard.Controls.Add(Me.uni8_7, 6, 7)
        Me.LEDboard.Controls.Add(Me.uni8_8, 7, 7)
        Me.LEDboard.Location = New System.Drawing.Point(181, 12)
        Me.LEDboard.Name = "LEDboard"
        Me.LEDboard.RowCount = 8
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.LEDboard.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.LEDboard.Size = New System.Drawing.Size(440, 440)
        Me.LEDboard.TabIndex = 10
        '
        'uni1_1
        '
        Me.uni1_1.BackColor = System.Drawing.Color.Gray
        Me.uni1_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_1.Location = New System.Drawing.Point(3, 3)
        Me.uni1_1.Name = "uni1_1"
        Me.uni1_1.Size = New System.Drawing.Size(49, 49)
        Me.uni1_1.TabIndex = 0
        Me.uni1_1.UseVisualStyleBackColor = False
        '
        'uni1_2
        '
        Me.uni1_2.BackColor = System.Drawing.Color.Gray
        Me.uni1_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_2.ForeColor = System.Drawing.Color.Black
        Me.uni1_2.Location = New System.Drawing.Point(58, 3)
        Me.uni1_2.Name = "uni1_2"
        Me.uni1_2.Size = New System.Drawing.Size(49, 49)
        Me.uni1_2.TabIndex = 1
        Me.uni1_2.UseVisualStyleBackColor = False
        '
        'uni1_3
        '
        Me.uni1_3.BackColor = System.Drawing.Color.Gray
        Me.uni1_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_3.ForeColor = System.Drawing.Color.Black
        Me.uni1_3.Location = New System.Drawing.Point(113, 3)
        Me.uni1_3.Name = "uni1_3"
        Me.uni1_3.Size = New System.Drawing.Size(49, 49)
        Me.uni1_3.TabIndex = 1
        Me.uni1_3.UseVisualStyleBackColor = False
        '
        'uni1_4
        '
        Me.uni1_4.BackColor = System.Drawing.Color.Gray
        Me.uni1_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_4.ForeColor = System.Drawing.Color.Black
        Me.uni1_4.Location = New System.Drawing.Point(168, 3)
        Me.uni1_4.Name = "uni1_4"
        Me.uni1_4.Size = New System.Drawing.Size(49, 49)
        Me.uni1_4.TabIndex = 1
        Me.uni1_4.UseVisualStyleBackColor = False
        '
        'uni1_5
        '
        Me.uni1_5.BackColor = System.Drawing.Color.Gray
        Me.uni1_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_5.ForeColor = System.Drawing.Color.Black
        Me.uni1_5.Location = New System.Drawing.Point(223, 3)
        Me.uni1_5.Name = "uni1_5"
        Me.uni1_5.Size = New System.Drawing.Size(49, 49)
        Me.uni1_5.TabIndex = 1
        Me.uni1_5.UseVisualStyleBackColor = False
        '
        'uni1_6
        '
        Me.uni1_6.BackColor = System.Drawing.Color.Gray
        Me.uni1_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_6.ForeColor = System.Drawing.Color.Black
        Me.uni1_6.Location = New System.Drawing.Point(278, 3)
        Me.uni1_6.Name = "uni1_6"
        Me.uni1_6.Size = New System.Drawing.Size(49, 49)
        Me.uni1_6.TabIndex = 1
        Me.uni1_6.UseVisualStyleBackColor = False
        '
        'uni1_7
        '
        Me.uni1_7.BackColor = System.Drawing.Color.Gray
        Me.uni1_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_7.ForeColor = System.Drawing.Color.Black
        Me.uni1_7.Location = New System.Drawing.Point(333, 3)
        Me.uni1_7.Name = "uni1_7"
        Me.uni1_7.Size = New System.Drawing.Size(49, 49)
        Me.uni1_7.TabIndex = 1
        Me.uni1_7.UseVisualStyleBackColor = False
        '
        'uni1_8
        '
        Me.uni1_8.BackColor = System.Drawing.Color.Gray
        Me.uni1_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_8.ForeColor = System.Drawing.Color.Black
        Me.uni1_8.Location = New System.Drawing.Point(388, 3)
        Me.uni1_8.Name = "uni1_8"
        Me.uni1_8.Size = New System.Drawing.Size(49, 49)
        Me.uni1_8.TabIndex = 1
        Me.uni1_8.UseVisualStyleBackColor = False
        '
        'uni2_1
        '
        Me.uni2_1.BackColor = System.Drawing.Color.Gray
        Me.uni2_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_1.ForeColor = System.Drawing.Color.Black
        Me.uni2_1.Location = New System.Drawing.Point(3, 58)
        Me.uni2_1.Name = "uni2_1"
        Me.uni2_1.Size = New System.Drawing.Size(49, 49)
        Me.uni2_1.TabIndex = 1
        Me.uni2_1.UseVisualStyleBackColor = False
        '
        'uni2_2
        '
        Me.uni2_2.BackColor = System.Drawing.Color.Gray
        Me.uni2_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_2.ForeColor = System.Drawing.Color.Black
        Me.uni2_2.Location = New System.Drawing.Point(58, 58)
        Me.uni2_2.Name = "uni2_2"
        Me.uni2_2.Size = New System.Drawing.Size(49, 49)
        Me.uni2_2.TabIndex = 1
        Me.uni2_2.UseVisualStyleBackColor = False
        '
        'uni2_3
        '
        Me.uni2_3.BackColor = System.Drawing.Color.Gray
        Me.uni2_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_3.ForeColor = System.Drawing.Color.Black
        Me.uni2_3.Location = New System.Drawing.Point(113, 58)
        Me.uni2_3.Name = "uni2_3"
        Me.uni2_3.Size = New System.Drawing.Size(49, 49)
        Me.uni2_3.TabIndex = 1
        Me.uni2_3.UseVisualStyleBackColor = False
        '
        'uni2_4
        '
        Me.uni2_4.BackColor = System.Drawing.Color.Gray
        Me.uni2_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_4.ForeColor = System.Drawing.Color.Black
        Me.uni2_4.Location = New System.Drawing.Point(168, 58)
        Me.uni2_4.Name = "uni2_4"
        Me.uni2_4.Size = New System.Drawing.Size(49, 49)
        Me.uni2_4.TabIndex = 1
        Me.uni2_4.UseVisualStyleBackColor = False
        '
        'uni2_5
        '
        Me.uni2_5.BackColor = System.Drawing.Color.Gray
        Me.uni2_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_5.ForeColor = System.Drawing.Color.Black
        Me.uni2_5.Location = New System.Drawing.Point(223, 58)
        Me.uni2_5.Name = "uni2_5"
        Me.uni2_5.Size = New System.Drawing.Size(49, 49)
        Me.uni2_5.TabIndex = 1
        Me.uni2_5.UseVisualStyleBackColor = False
        '
        'uni2_6
        '
        Me.uni2_6.BackColor = System.Drawing.Color.Gray
        Me.uni2_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_6.ForeColor = System.Drawing.Color.Black
        Me.uni2_6.Location = New System.Drawing.Point(278, 58)
        Me.uni2_6.Name = "uni2_6"
        Me.uni2_6.Size = New System.Drawing.Size(49, 49)
        Me.uni2_6.TabIndex = 1
        Me.uni2_6.UseVisualStyleBackColor = False
        '
        'uni2_7
        '
        Me.uni2_7.BackColor = System.Drawing.Color.Gray
        Me.uni2_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_7.ForeColor = System.Drawing.Color.Black
        Me.uni2_7.Location = New System.Drawing.Point(333, 58)
        Me.uni2_7.Name = "uni2_7"
        Me.uni2_7.Size = New System.Drawing.Size(49, 49)
        Me.uni2_7.TabIndex = 1
        Me.uni2_7.UseVisualStyleBackColor = False
        '
        'uni2_8
        '
        Me.uni2_8.BackColor = System.Drawing.Color.Gray
        Me.uni2_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_8.ForeColor = System.Drawing.Color.Black
        Me.uni2_8.Location = New System.Drawing.Point(388, 58)
        Me.uni2_8.Name = "uni2_8"
        Me.uni2_8.Size = New System.Drawing.Size(49, 49)
        Me.uni2_8.TabIndex = 1
        Me.uni2_8.UseVisualStyleBackColor = False
        '
        'uni3_1
        '
        Me.uni3_1.BackColor = System.Drawing.Color.Gray
        Me.uni3_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_1.ForeColor = System.Drawing.Color.Black
        Me.uni3_1.Location = New System.Drawing.Point(3, 113)
        Me.uni3_1.Name = "uni3_1"
        Me.uni3_1.Size = New System.Drawing.Size(49, 49)
        Me.uni3_1.TabIndex = 1
        Me.uni3_1.UseVisualStyleBackColor = False
        '
        'uni3_2
        '
        Me.uni3_2.BackColor = System.Drawing.Color.Gray
        Me.uni3_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_2.ForeColor = System.Drawing.Color.Black
        Me.uni3_2.Location = New System.Drawing.Point(58, 113)
        Me.uni3_2.Name = "uni3_2"
        Me.uni3_2.Size = New System.Drawing.Size(49, 49)
        Me.uni3_2.TabIndex = 1
        Me.uni3_2.UseVisualStyleBackColor = False
        '
        'uni3_3
        '
        Me.uni3_3.BackColor = System.Drawing.Color.Gray
        Me.uni3_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_3.ForeColor = System.Drawing.Color.Black
        Me.uni3_3.Location = New System.Drawing.Point(113, 113)
        Me.uni3_3.Name = "uni3_3"
        Me.uni3_3.Size = New System.Drawing.Size(49, 49)
        Me.uni3_3.TabIndex = 1
        Me.uni3_3.UseVisualStyleBackColor = False
        '
        'uni3_4
        '
        Me.uni3_4.BackColor = System.Drawing.Color.Gray
        Me.uni3_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_4.ForeColor = System.Drawing.Color.Black
        Me.uni3_4.Location = New System.Drawing.Point(168, 113)
        Me.uni3_4.Name = "uni3_4"
        Me.uni3_4.Size = New System.Drawing.Size(49, 49)
        Me.uni3_4.TabIndex = 1
        Me.uni3_4.UseVisualStyleBackColor = False
        '
        'uni3_5
        '
        Me.uni3_5.BackColor = System.Drawing.Color.Gray
        Me.uni3_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_5.ForeColor = System.Drawing.Color.Black
        Me.uni3_5.Location = New System.Drawing.Point(223, 113)
        Me.uni3_5.Name = "uni3_5"
        Me.uni3_5.Size = New System.Drawing.Size(49, 49)
        Me.uni3_5.TabIndex = 1
        Me.uni3_5.UseVisualStyleBackColor = False
        '
        'uni3_6
        '
        Me.uni3_6.BackColor = System.Drawing.Color.Gray
        Me.uni3_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_6.ForeColor = System.Drawing.Color.Black
        Me.uni3_6.Location = New System.Drawing.Point(278, 113)
        Me.uni3_6.Name = "uni3_6"
        Me.uni3_6.Size = New System.Drawing.Size(49, 49)
        Me.uni3_6.TabIndex = 1
        Me.uni3_6.UseVisualStyleBackColor = False
        '
        'uni3_7
        '
        Me.uni3_7.BackColor = System.Drawing.Color.Gray
        Me.uni3_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_7.ForeColor = System.Drawing.Color.Black
        Me.uni3_7.Location = New System.Drawing.Point(333, 113)
        Me.uni3_7.Name = "uni3_7"
        Me.uni3_7.Size = New System.Drawing.Size(49, 49)
        Me.uni3_7.TabIndex = 1
        Me.uni3_7.UseVisualStyleBackColor = False
        '
        'uni3_8
        '
        Me.uni3_8.BackColor = System.Drawing.Color.Gray
        Me.uni3_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_8.ForeColor = System.Drawing.Color.Black
        Me.uni3_8.Location = New System.Drawing.Point(388, 113)
        Me.uni3_8.Name = "uni3_8"
        Me.uni3_8.Size = New System.Drawing.Size(49, 49)
        Me.uni3_8.TabIndex = 1
        Me.uni3_8.UseVisualStyleBackColor = False
        '
        'uni4_1
        '
        Me.uni4_1.BackColor = System.Drawing.Color.Gray
        Me.uni4_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_1.ForeColor = System.Drawing.Color.Black
        Me.uni4_1.Location = New System.Drawing.Point(3, 168)
        Me.uni4_1.Name = "uni4_1"
        Me.uni4_1.Size = New System.Drawing.Size(49, 49)
        Me.uni4_1.TabIndex = 1
        Me.uni4_1.UseVisualStyleBackColor = False
        '
        'uni4_2
        '
        Me.uni4_2.BackColor = System.Drawing.Color.Gray
        Me.uni4_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_2.ForeColor = System.Drawing.Color.Black
        Me.uni4_2.Location = New System.Drawing.Point(58, 168)
        Me.uni4_2.Name = "uni4_2"
        Me.uni4_2.Size = New System.Drawing.Size(49, 49)
        Me.uni4_2.TabIndex = 1
        Me.uni4_2.UseVisualStyleBackColor = False
        '
        'uni4_3
        '
        Me.uni4_3.BackColor = System.Drawing.Color.Gray
        Me.uni4_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_3.ForeColor = System.Drawing.Color.Black
        Me.uni4_3.Location = New System.Drawing.Point(113, 168)
        Me.uni4_3.Name = "uni4_3"
        Me.uni4_3.Size = New System.Drawing.Size(49, 49)
        Me.uni4_3.TabIndex = 1
        Me.uni4_3.UseVisualStyleBackColor = False
        '
        'uni4_4
        '
        Me.uni4_4.BackColor = System.Drawing.Color.Gray
        Me.uni4_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_4.ForeColor = System.Drawing.Color.Black
        Me.uni4_4.Location = New System.Drawing.Point(168, 168)
        Me.uni4_4.Name = "uni4_4"
        Me.uni4_4.Size = New System.Drawing.Size(49, 49)
        Me.uni4_4.TabIndex = 1
        Me.uni4_4.UseVisualStyleBackColor = False
        '
        'uni4_5
        '
        Me.uni4_5.BackColor = System.Drawing.Color.Gray
        Me.uni4_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_5.ForeColor = System.Drawing.Color.Black
        Me.uni4_5.Location = New System.Drawing.Point(223, 168)
        Me.uni4_5.Name = "uni4_5"
        Me.uni4_5.Size = New System.Drawing.Size(49, 49)
        Me.uni4_5.TabIndex = 1
        Me.uni4_5.UseVisualStyleBackColor = False
        '
        'uni4_6
        '
        Me.uni4_6.BackColor = System.Drawing.Color.Gray
        Me.uni4_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_6.ForeColor = System.Drawing.Color.Black
        Me.uni4_6.Location = New System.Drawing.Point(278, 168)
        Me.uni4_6.Name = "uni4_6"
        Me.uni4_6.Size = New System.Drawing.Size(49, 49)
        Me.uni4_6.TabIndex = 1
        Me.uni4_6.UseVisualStyleBackColor = False
        '
        'uni4_7
        '
        Me.uni4_7.BackColor = System.Drawing.Color.Gray
        Me.uni4_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_7.ForeColor = System.Drawing.Color.Black
        Me.uni4_7.Location = New System.Drawing.Point(333, 168)
        Me.uni4_7.Name = "uni4_7"
        Me.uni4_7.Size = New System.Drawing.Size(49, 49)
        Me.uni4_7.TabIndex = 1
        Me.uni4_7.UseVisualStyleBackColor = False
        '
        'uni4_8
        '
        Me.uni4_8.BackColor = System.Drawing.Color.Gray
        Me.uni4_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_8.ForeColor = System.Drawing.Color.Black
        Me.uni4_8.Location = New System.Drawing.Point(388, 168)
        Me.uni4_8.Name = "uni4_8"
        Me.uni4_8.Size = New System.Drawing.Size(49, 49)
        Me.uni4_8.TabIndex = 1
        Me.uni4_8.UseVisualStyleBackColor = False
        '
        'uni5_1
        '
        Me.uni5_1.BackColor = System.Drawing.Color.Gray
        Me.uni5_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_1.ForeColor = System.Drawing.Color.Black
        Me.uni5_1.Location = New System.Drawing.Point(3, 223)
        Me.uni5_1.Name = "uni5_1"
        Me.uni5_1.Size = New System.Drawing.Size(49, 49)
        Me.uni5_1.TabIndex = 1
        Me.uni5_1.UseVisualStyleBackColor = False
        '
        'uni5_2
        '
        Me.uni5_2.BackColor = System.Drawing.Color.Gray
        Me.uni5_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_2.ForeColor = System.Drawing.Color.Black
        Me.uni5_2.Location = New System.Drawing.Point(58, 223)
        Me.uni5_2.Name = "uni5_2"
        Me.uni5_2.Size = New System.Drawing.Size(49, 49)
        Me.uni5_2.TabIndex = 1
        Me.uni5_2.UseVisualStyleBackColor = False
        '
        'uni5_3
        '
        Me.uni5_3.BackColor = System.Drawing.Color.Gray
        Me.uni5_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_3.ForeColor = System.Drawing.Color.Black
        Me.uni5_3.Location = New System.Drawing.Point(113, 223)
        Me.uni5_3.Name = "uni5_3"
        Me.uni5_3.Size = New System.Drawing.Size(49, 49)
        Me.uni5_3.TabIndex = 1
        Me.uni5_3.UseVisualStyleBackColor = False
        '
        'uni5_4
        '
        Me.uni5_4.BackColor = System.Drawing.Color.Gray
        Me.uni5_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_4.ForeColor = System.Drawing.Color.Black
        Me.uni5_4.Location = New System.Drawing.Point(168, 223)
        Me.uni5_4.Name = "uni5_4"
        Me.uni5_4.Size = New System.Drawing.Size(49, 49)
        Me.uni5_4.TabIndex = 1
        Me.uni5_4.UseVisualStyleBackColor = False
        '
        'uni5_5
        '
        Me.uni5_5.BackColor = System.Drawing.Color.Gray
        Me.uni5_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_5.ForeColor = System.Drawing.Color.Black
        Me.uni5_5.Location = New System.Drawing.Point(223, 223)
        Me.uni5_5.Name = "uni5_5"
        Me.uni5_5.Size = New System.Drawing.Size(49, 49)
        Me.uni5_5.TabIndex = 1
        Me.uni5_5.UseVisualStyleBackColor = False
        '
        'uni5_6
        '
        Me.uni5_6.BackColor = System.Drawing.Color.Gray
        Me.uni5_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_6.ForeColor = System.Drawing.Color.Black
        Me.uni5_6.Location = New System.Drawing.Point(278, 223)
        Me.uni5_6.Name = "uni5_6"
        Me.uni5_6.Size = New System.Drawing.Size(49, 49)
        Me.uni5_6.TabIndex = 1
        Me.uni5_6.UseVisualStyleBackColor = False
        '
        'uni5_7
        '
        Me.uni5_7.BackColor = System.Drawing.Color.Gray
        Me.uni5_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_7.ForeColor = System.Drawing.Color.Black
        Me.uni5_7.Location = New System.Drawing.Point(333, 223)
        Me.uni5_7.Name = "uni5_7"
        Me.uni5_7.Size = New System.Drawing.Size(49, 49)
        Me.uni5_7.TabIndex = 1
        Me.uni5_7.UseVisualStyleBackColor = False
        '
        'uni5_8
        '
        Me.uni5_8.BackColor = System.Drawing.Color.Gray
        Me.uni5_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_8.ForeColor = System.Drawing.Color.Black
        Me.uni5_8.Location = New System.Drawing.Point(388, 223)
        Me.uni5_8.Name = "uni5_8"
        Me.uni5_8.Size = New System.Drawing.Size(49, 49)
        Me.uni5_8.TabIndex = 1
        Me.uni5_8.UseVisualStyleBackColor = False
        '
        'uni6_1
        '
        Me.uni6_1.BackColor = System.Drawing.Color.Gray
        Me.uni6_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_1.ForeColor = System.Drawing.Color.Black
        Me.uni6_1.Location = New System.Drawing.Point(3, 278)
        Me.uni6_1.Name = "uni6_1"
        Me.uni6_1.Size = New System.Drawing.Size(49, 49)
        Me.uni6_1.TabIndex = 1
        Me.uni6_1.UseVisualStyleBackColor = False
        '
        'uni6_2
        '
        Me.uni6_2.BackColor = System.Drawing.Color.Gray
        Me.uni6_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_2.ForeColor = System.Drawing.Color.Black
        Me.uni6_2.Location = New System.Drawing.Point(58, 278)
        Me.uni6_2.Name = "uni6_2"
        Me.uni6_2.Size = New System.Drawing.Size(49, 49)
        Me.uni6_2.TabIndex = 1
        Me.uni6_2.UseVisualStyleBackColor = False
        '
        'uni6_3
        '
        Me.uni6_3.BackColor = System.Drawing.Color.Gray
        Me.uni6_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_3.ForeColor = System.Drawing.Color.Black
        Me.uni6_3.Location = New System.Drawing.Point(113, 278)
        Me.uni6_3.Name = "uni6_3"
        Me.uni6_3.Size = New System.Drawing.Size(49, 49)
        Me.uni6_3.TabIndex = 1
        Me.uni6_3.UseVisualStyleBackColor = False
        '
        'uni6_4
        '
        Me.uni6_4.BackColor = System.Drawing.Color.Gray
        Me.uni6_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_4.ForeColor = System.Drawing.Color.Black
        Me.uni6_4.Location = New System.Drawing.Point(168, 278)
        Me.uni6_4.Name = "uni6_4"
        Me.uni6_4.Size = New System.Drawing.Size(49, 49)
        Me.uni6_4.TabIndex = 1
        Me.uni6_4.UseVisualStyleBackColor = False
        '
        'uni6_5
        '
        Me.uni6_5.BackColor = System.Drawing.Color.Gray
        Me.uni6_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_5.ForeColor = System.Drawing.Color.Black
        Me.uni6_5.Location = New System.Drawing.Point(223, 278)
        Me.uni6_5.Name = "uni6_5"
        Me.uni6_5.Size = New System.Drawing.Size(49, 49)
        Me.uni6_5.TabIndex = 1
        Me.uni6_5.UseVisualStyleBackColor = False
        '
        'uni6_6
        '
        Me.uni6_6.BackColor = System.Drawing.Color.Gray
        Me.uni6_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_6.ForeColor = System.Drawing.Color.Black
        Me.uni6_6.Location = New System.Drawing.Point(278, 278)
        Me.uni6_6.Name = "uni6_6"
        Me.uni6_6.Size = New System.Drawing.Size(49, 49)
        Me.uni6_6.TabIndex = 1
        Me.uni6_6.UseVisualStyleBackColor = False
        '
        'uni6_7
        '
        Me.uni6_7.BackColor = System.Drawing.Color.Gray
        Me.uni6_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_7.ForeColor = System.Drawing.Color.Black
        Me.uni6_7.Location = New System.Drawing.Point(333, 278)
        Me.uni6_7.Name = "uni6_7"
        Me.uni6_7.Size = New System.Drawing.Size(49, 49)
        Me.uni6_7.TabIndex = 1
        Me.uni6_7.UseVisualStyleBackColor = False
        '
        'uni6_8
        '
        Me.uni6_8.BackColor = System.Drawing.Color.Gray
        Me.uni6_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_8.ForeColor = System.Drawing.Color.Black
        Me.uni6_8.Location = New System.Drawing.Point(388, 278)
        Me.uni6_8.Name = "uni6_8"
        Me.uni6_8.Size = New System.Drawing.Size(49, 49)
        Me.uni6_8.TabIndex = 1
        Me.uni6_8.UseVisualStyleBackColor = False
        '
        'uni7_1
        '
        Me.uni7_1.BackColor = System.Drawing.Color.Gray
        Me.uni7_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_1.ForeColor = System.Drawing.Color.Black
        Me.uni7_1.Location = New System.Drawing.Point(3, 333)
        Me.uni7_1.Name = "uni7_1"
        Me.uni7_1.Size = New System.Drawing.Size(49, 49)
        Me.uni7_1.TabIndex = 1
        Me.uni7_1.UseVisualStyleBackColor = False
        '
        'uni7_2
        '
        Me.uni7_2.BackColor = System.Drawing.Color.Gray
        Me.uni7_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_2.ForeColor = System.Drawing.Color.Black
        Me.uni7_2.Location = New System.Drawing.Point(58, 333)
        Me.uni7_2.Name = "uni7_2"
        Me.uni7_2.Size = New System.Drawing.Size(49, 49)
        Me.uni7_2.TabIndex = 1
        Me.uni7_2.UseVisualStyleBackColor = False
        '
        'uni7_3
        '
        Me.uni7_3.BackColor = System.Drawing.Color.Gray
        Me.uni7_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_3.ForeColor = System.Drawing.Color.Black
        Me.uni7_3.Location = New System.Drawing.Point(113, 333)
        Me.uni7_3.Name = "uni7_3"
        Me.uni7_3.Size = New System.Drawing.Size(49, 49)
        Me.uni7_3.TabIndex = 1
        Me.uni7_3.UseVisualStyleBackColor = False
        '
        'uni7_4
        '
        Me.uni7_4.BackColor = System.Drawing.Color.Gray
        Me.uni7_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_4.ForeColor = System.Drawing.Color.Black
        Me.uni7_4.Location = New System.Drawing.Point(168, 333)
        Me.uni7_4.Name = "uni7_4"
        Me.uni7_4.Size = New System.Drawing.Size(49, 49)
        Me.uni7_4.TabIndex = 1
        Me.uni7_4.UseVisualStyleBackColor = False
        '
        'uni7_5
        '
        Me.uni7_5.BackColor = System.Drawing.Color.Gray
        Me.uni7_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_5.ForeColor = System.Drawing.Color.Black
        Me.uni7_5.Location = New System.Drawing.Point(223, 333)
        Me.uni7_5.Name = "uni7_5"
        Me.uni7_5.Size = New System.Drawing.Size(49, 49)
        Me.uni7_5.TabIndex = 1
        Me.uni7_5.UseVisualStyleBackColor = False
        '
        'uni7_6
        '
        Me.uni7_6.BackColor = System.Drawing.Color.Gray
        Me.uni7_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_6.ForeColor = System.Drawing.Color.Black
        Me.uni7_6.Location = New System.Drawing.Point(278, 333)
        Me.uni7_6.Name = "uni7_6"
        Me.uni7_6.Size = New System.Drawing.Size(49, 49)
        Me.uni7_6.TabIndex = 1
        Me.uni7_6.UseVisualStyleBackColor = False
        '
        'uni7_7
        '
        Me.uni7_7.BackColor = System.Drawing.Color.Gray
        Me.uni7_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_7.ForeColor = System.Drawing.Color.Black
        Me.uni7_7.Location = New System.Drawing.Point(333, 333)
        Me.uni7_7.Name = "uni7_7"
        Me.uni7_7.Size = New System.Drawing.Size(49, 49)
        Me.uni7_7.TabIndex = 1
        Me.uni7_7.UseVisualStyleBackColor = False
        '
        'uni7_8
        '
        Me.uni7_8.BackColor = System.Drawing.Color.Gray
        Me.uni7_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_8.ForeColor = System.Drawing.Color.Black
        Me.uni7_8.Location = New System.Drawing.Point(388, 333)
        Me.uni7_8.Name = "uni7_8"
        Me.uni7_8.Size = New System.Drawing.Size(49, 49)
        Me.uni7_8.TabIndex = 1
        Me.uni7_8.UseVisualStyleBackColor = False
        '
        'uni8_1
        '
        Me.uni8_1.BackColor = System.Drawing.Color.Gray
        Me.uni8_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_1.ForeColor = System.Drawing.Color.Black
        Me.uni8_1.Location = New System.Drawing.Point(3, 388)
        Me.uni8_1.Name = "uni8_1"
        Me.uni8_1.Size = New System.Drawing.Size(49, 49)
        Me.uni8_1.TabIndex = 1
        Me.uni8_1.UseVisualStyleBackColor = False
        '
        'uni8_2
        '
        Me.uni8_2.BackColor = System.Drawing.Color.Gray
        Me.uni8_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_2.ForeColor = System.Drawing.Color.Black
        Me.uni8_2.Location = New System.Drawing.Point(58, 388)
        Me.uni8_2.Name = "uni8_2"
        Me.uni8_2.Size = New System.Drawing.Size(49, 49)
        Me.uni8_2.TabIndex = 1
        Me.uni8_2.UseVisualStyleBackColor = False
        '
        'uni8_3
        '
        Me.uni8_3.BackColor = System.Drawing.Color.Gray
        Me.uni8_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_3.ForeColor = System.Drawing.Color.Black
        Me.uni8_3.Location = New System.Drawing.Point(113, 388)
        Me.uni8_3.Name = "uni8_3"
        Me.uni8_3.Size = New System.Drawing.Size(49, 49)
        Me.uni8_3.TabIndex = 1
        Me.uni8_3.UseVisualStyleBackColor = False
        '
        'uni8_4
        '
        Me.uni8_4.BackColor = System.Drawing.Color.Gray
        Me.uni8_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_4.ForeColor = System.Drawing.Color.Black
        Me.uni8_4.Location = New System.Drawing.Point(168, 388)
        Me.uni8_4.Name = "uni8_4"
        Me.uni8_4.Size = New System.Drawing.Size(49, 49)
        Me.uni8_4.TabIndex = 1
        Me.uni8_4.UseVisualStyleBackColor = False
        '
        'uni8_5
        '
        Me.uni8_5.BackColor = System.Drawing.Color.Gray
        Me.uni8_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_5.ForeColor = System.Drawing.Color.Black
        Me.uni8_5.Location = New System.Drawing.Point(223, 388)
        Me.uni8_5.Name = "uni8_5"
        Me.uni8_5.Size = New System.Drawing.Size(49, 49)
        Me.uni8_5.TabIndex = 1
        Me.uni8_5.UseVisualStyleBackColor = False
        '
        'uni8_6
        '
        Me.uni8_6.BackColor = System.Drawing.Color.Gray
        Me.uni8_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_6.ForeColor = System.Drawing.Color.Black
        Me.uni8_6.Location = New System.Drawing.Point(278, 388)
        Me.uni8_6.Name = "uni8_6"
        Me.uni8_6.Size = New System.Drawing.Size(49, 49)
        Me.uni8_6.TabIndex = 1
        Me.uni8_6.UseVisualStyleBackColor = False
        '
        'uni8_7
        '
        Me.uni8_7.BackColor = System.Drawing.Color.Gray
        Me.uni8_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_7.ForeColor = System.Drawing.Color.Black
        Me.uni8_7.Location = New System.Drawing.Point(333, 388)
        Me.uni8_7.Name = "uni8_7"
        Me.uni8_7.Size = New System.Drawing.Size(49, 49)
        Me.uni8_7.TabIndex = 1
        Me.uni8_7.UseVisualStyleBackColor = False
        '
        'uni8_8
        '
        Me.uni8_8.BackColor = System.Drawing.Color.Gray
        Me.uni8_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_8.ForeColor = System.Drawing.Color.Black
        Me.uni8_8.Location = New System.Drawing.Point(388, 388)
        Me.uni8_8.Name = "uni8_8"
        Me.uni8_8.Size = New System.Drawing.Size(49, 49)
        Me.uni8_8.TabIndex = 1
        Me.uni8_8.UseVisualStyleBackColor = False
        '
        'imgThumb
        '
        Me.imgThumb.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imgThumb.ImageSize = New System.Drawing.Size(16, 16)
        Me.imgThumb.TransparentColor = System.Drawing.Color.Transparent
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(640, 368)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 46)
        Me.btnSave.TabIndex = 12
        Me.btnSave.Text = "Button1"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'listLEDs
        '
        Me.listLEDs.FormattingEnabled = True
        Me.listLEDs.ItemHeight = 12
        Me.listLEDs.Location = New System.Drawing.Point(12, 15)
        Me.listLEDs.Name = "listLEDs"
        Me.listLEDs.Size = New System.Drawing.Size(150, 268)
        Me.listLEDs.TabIndex = 13
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 290)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(62, 23)
        Me.Button1.TabIndex = 15
        Me.Button1.Text = "Down"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(100, 290)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(62, 23)
        Me.Button2.TabIndex = 16
        Me.Button2.Text = "Up"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'listorder
        '
        Me.listorder.Font = New System.Drawing.Font("맑은 고딕", 11.0!)
        Me.listorder.FormattingEnabled = True
        Me.listorder.ItemHeight = 20
        Me.listorder.Location = New System.Drawing.Point(12, 319)
        Me.listorder.Name = "listorder"
        Me.listorder.Size = New System.Drawing.Size(120, 144)
        Me.listorder.TabIndex = 17
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripComboBox1})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(182, 31)
        '
        'ToolStripComboBox1
        '
        Me.ToolStripComboBox1.Name = "ToolStripComboBox1"
        Me.ToolStripComboBox1.Size = New System.Drawing.Size(121, 23)
        '
        'dotLEDEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(738, 487)
        Me.Controls.Add(Me.listorder)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.listLEDs)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.LEDboard)
        Me.Name = "dotLEDEdit"
        Me.Text = "dotLEDEdit"
        Me.LEDboard.ResumeLayout(False)
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LEDboard As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents uni1_1 As System.Windows.Forms.Button
    Friend WithEvents uni1_2 As System.Windows.Forms.Button
    Friend WithEvents uni1_3 As System.Windows.Forms.Button
    Friend WithEvents uni1_4 As System.Windows.Forms.Button
    Friend WithEvents uni1_5 As System.Windows.Forms.Button
    Friend WithEvents uni1_6 As System.Windows.Forms.Button
    Friend WithEvents uni1_7 As System.Windows.Forms.Button
    Friend WithEvents uni1_8 As System.Windows.Forms.Button
    Friend WithEvents uni2_1 As System.Windows.Forms.Button
    Friend WithEvents uni2_2 As System.Windows.Forms.Button
    Friend WithEvents uni2_3 As System.Windows.Forms.Button
    Friend WithEvents uni2_4 As System.Windows.Forms.Button
    Friend WithEvents uni2_5 As System.Windows.Forms.Button
    Friend WithEvents uni2_6 As System.Windows.Forms.Button
    Friend WithEvents uni2_7 As System.Windows.Forms.Button
    Friend WithEvents uni2_8 As System.Windows.Forms.Button
    Friend WithEvents uni3_1 As System.Windows.Forms.Button
    Friend WithEvents uni3_2 As System.Windows.Forms.Button
    Friend WithEvents uni3_3 As System.Windows.Forms.Button
    Friend WithEvents uni3_4 As System.Windows.Forms.Button
    Friend WithEvents uni3_5 As System.Windows.Forms.Button
    Friend WithEvents uni3_6 As System.Windows.Forms.Button
    Friend WithEvents uni3_7 As System.Windows.Forms.Button
    Friend WithEvents uni3_8 As System.Windows.Forms.Button
    Friend WithEvents uni4_1 As System.Windows.Forms.Button
    Friend WithEvents uni4_2 As System.Windows.Forms.Button
    Friend WithEvents uni4_3 As System.Windows.Forms.Button
    Friend WithEvents uni4_4 As System.Windows.Forms.Button
    Friend WithEvents uni4_5 As System.Windows.Forms.Button
    Friend WithEvents uni4_6 As System.Windows.Forms.Button
    Friend WithEvents uni4_7 As System.Windows.Forms.Button
    Friend WithEvents uni4_8 As System.Windows.Forms.Button
    Friend WithEvents uni5_1 As System.Windows.Forms.Button
    Friend WithEvents uni5_2 As System.Windows.Forms.Button
    Friend WithEvents uni5_3 As System.Windows.Forms.Button
    Friend WithEvents uni5_4 As System.Windows.Forms.Button
    Friend WithEvents uni5_5 As System.Windows.Forms.Button
    Friend WithEvents uni5_6 As System.Windows.Forms.Button
    Friend WithEvents uni5_7 As System.Windows.Forms.Button
    Friend WithEvents uni5_8 As System.Windows.Forms.Button
    Friend WithEvents uni6_1 As System.Windows.Forms.Button
    Friend WithEvents uni6_2 As System.Windows.Forms.Button
    Friend WithEvents uni6_3 As System.Windows.Forms.Button
    Friend WithEvents uni6_4 As System.Windows.Forms.Button
    Friend WithEvents uni6_5 As System.Windows.Forms.Button
    Friend WithEvents uni6_6 As System.Windows.Forms.Button
    Friend WithEvents uni6_7 As System.Windows.Forms.Button
    Friend WithEvents uni6_8 As System.Windows.Forms.Button
    Friend WithEvents uni7_1 As System.Windows.Forms.Button
    Friend WithEvents uni7_2 As System.Windows.Forms.Button
    Friend WithEvents uni7_3 As System.Windows.Forms.Button
    Friend WithEvents uni7_4 As System.Windows.Forms.Button
    Friend WithEvents uni7_5 As System.Windows.Forms.Button
    Friend WithEvents uni7_6 As System.Windows.Forms.Button
    Friend WithEvents uni7_7 As System.Windows.Forms.Button
    Friend WithEvents uni7_8 As System.Windows.Forms.Button
    Friend WithEvents uni8_1 As System.Windows.Forms.Button
    Friend WithEvents uni8_2 As System.Windows.Forms.Button
    Friend WithEvents uni8_3 As System.Windows.Forms.Button
    Friend WithEvents uni8_4 As System.Windows.Forms.Button
    Friend WithEvents uni8_5 As System.Windows.Forms.Button
    Friend WithEvents uni8_6 As System.Windows.Forms.Button
    Friend WithEvents uni8_7 As System.Windows.Forms.Button
    Friend WithEvents uni8_8 As System.Windows.Forms.Button
    Friend WithEvents imgThumb As System.Windows.Forms.ImageList
    Friend WithEvents colorPicker As System.Windows.Forms.ColorDialog
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents listLEDs As System.Windows.Forms.ListBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents listorder As System.Windows.Forms.ListBox
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripComboBox1 As System.Windows.Forms.ToolStripComboBox
End Class
