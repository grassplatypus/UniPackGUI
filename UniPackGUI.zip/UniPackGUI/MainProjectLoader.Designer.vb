﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainProjectLoader
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainProjectLoader))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.uni1_1 = New System.Windows.Forms.Button()
        Me.uni1_2 = New System.Windows.Forms.Button()
        Me.uni1_3 = New System.Windows.Forms.Button()
        Me.uni1_4 = New System.Windows.Forms.Button()
        Me.uni1_5 = New System.Windows.Forms.Button()
        Me.uni1_6 = New System.Windows.Forms.Button()
        Me.uni1_7 = New System.Windows.Forms.Button()
        Me.uni1_8 = New System.Windows.Forms.Button()
        Me.uni2_1 = New System.Windows.Forms.Button()
        Me.uni2_2 = New System.Windows.Forms.Button()
        Me.uni2_3 = New System.Windows.Forms.Button()
        Me.uni2_4 = New System.Windows.Forms.Button()
        Me.uni2_5 = New System.Windows.Forms.Button()
        Me.uni2_6 = New System.Windows.Forms.Button()
        Me.uni2_7 = New System.Windows.Forms.Button()
        Me.uni2_8 = New System.Windows.Forms.Button()
        Me.uni3_1 = New System.Windows.Forms.Button()
        Me.uni3_2 = New System.Windows.Forms.Button()
        Me.uni3_3 = New System.Windows.Forms.Button()
        Me.uni3_4 = New System.Windows.Forms.Button()
        Me.uni3_5 = New System.Windows.Forms.Button()
        Me.uni3_6 = New System.Windows.Forms.Button()
        Me.uni3_7 = New System.Windows.Forms.Button()
        Me.uni3_8 = New System.Windows.Forms.Button()
        Me.uni4_1 = New System.Windows.Forms.Button()
        Me.uni4_2 = New System.Windows.Forms.Button()
        Me.uni4_3 = New System.Windows.Forms.Button()
        Me.uni4_4 = New System.Windows.Forms.Button()
        Me.uni4_5 = New System.Windows.Forms.Button()
        Me.uni4_6 = New System.Windows.Forms.Button()
        Me.uni4_7 = New System.Windows.Forms.Button()
        Me.uni4_8 = New System.Windows.Forms.Button()
        Me.uni5_1 = New System.Windows.Forms.Button()
        Me.uni5_2 = New System.Windows.Forms.Button()
        Me.uni5_3 = New System.Windows.Forms.Button()
        Me.uni5_4 = New System.Windows.Forms.Button()
        Me.uni5_5 = New System.Windows.Forms.Button()
        Me.uni5_6 = New System.Windows.Forms.Button()
        Me.uni5_7 = New System.Windows.Forms.Button()
        Me.uni5_8 = New System.Windows.Forms.Button()
        Me.uni6_1 = New System.Windows.Forms.Button()
        Me.uni6_2 = New System.Windows.Forms.Button()
        Me.uni6_3 = New System.Windows.Forms.Button()
        Me.uni6_4 = New System.Windows.Forms.Button()
        Me.uni6_5 = New System.Windows.Forms.Button()
        Me.uni6_6 = New System.Windows.Forms.Button()
        Me.uni6_7 = New System.Windows.Forms.Button()
        Me.uni6_8 = New System.Windows.Forms.Button()
        Me.uni7_1 = New System.Windows.Forms.Button()
        Me.uni7_2 = New System.Windows.Forms.Button()
        Me.uni7_3 = New System.Windows.Forms.Button()
        Me.uni7_4 = New System.Windows.Forms.Button()
        Me.uni7_5 = New System.Windows.Forms.Button()
        Me.uni7_6 = New System.Windows.Forms.Button()
        Me.uni7_7 = New System.Windows.Forms.Button()
        Me.uni7_8 = New System.Windows.Forms.Button()
        Me.uni8_1 = New System.Windows.Forms.Button()
        Me.uni8_2 = New System.Windows.Forms.Button()
        Me.uni8_3 = New System.Windows.Forms.Button()
        Me.uni8_4 = New System.Windows.Forms.Button()
        Me.uni8_5 = New System.Windows.Forms.Button()
        Me.uni8_6 = New System.Windows.Forms.Button()
        Me.uni8_7 = New System.Windows.Forms.Button()
        Me.uni8_8 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rblededit = New System.Windows.Forms.RadioButton()
        Me.rbEditmode = New System.Windows.Forms.RadioButton()
        Me.rbPlaymode = New System.Windows.Forms.RadioButton()
        Me.menuMainProj = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Mp3ToWavConverterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.UploadToUniPackWWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SoundsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SoundCutterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeySoundTextEditorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AutoPlayTextEditorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ledisableenable = New System.Windows.Forms.ToolStripMenuItem()
        Me.TestNReleaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AutoPlayBetaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AutoPlayControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.PushToDeviceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConnectMidiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenSettingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestoreDefaultWindowSizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TestMakeCrashToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.groupUniPackInfo = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.labelInfSave = New System.Windows.Forms.Label()
        Me.tbPackChains = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbPackAuthor = New System.Windows.Forms.TextBox()
        Me.tbPackDirInfo = New System.Windows.Forms.TextBox()
        Me.tbPackName = New System.Windows.Forms.TextBox()
        Me.btnSavePackInfo = New System.Windows.Forms.Button()
        Me.listChain = New System.Windows.Forms.ListBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.saveAnothername = New System.Windows.Forms.SaveFileDialog()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnFlushLEDColor = New System.Windows.Forms.Button()
        Me.btnFlushSound = New System.Windows.Forms.Button()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.ofdOpenAgain = New System.Windows.Forms.OpenFileDialog()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.menuMainProj.SuspendLayout()
        Me.groupUniPackInfo.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel1.BackColor = System.Drawing.Color.LightGray
        Me.TableLayoutPanel1.ColumnCount = 8
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.95972!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.43433!))
        Me.TableLayoutPanel1.Controls.Add(Me.uni1_1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.uni1_2, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.uni1_3, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.uni1_4, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.uni1_5, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.uni1_6, 5, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.uni1_7, 6, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.uni1_8, 7, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.uni2_1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.uni2_2, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.uni2_3, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.uni2_4, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.uni2_5, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.uni2_6, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.uni2_7, 6, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.uni2_8, 7, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.uni3_1, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.uni3_2, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.uni3_3, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.uni3_4, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.uni3_5, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.uni3_6, 5, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.uni3_7, 6, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.uni3_8, 7, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.uni4_1, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.uni4_2, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.uni4_3, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.uni4_4, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.uni4_5, 4, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.uni4_6, 5, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.uni4_7, 6, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.uni4_8, 7, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.uni5_1, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.uni5_2, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.uni5_3, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.uni5_4, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.uni5_5, 4, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.uni5_6, 5, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.uni5_7, 6, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.uni5_8, 7, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.uni6_1, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.uni6_2, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.uni6_3, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.uni6_4, 3, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.uni6_5, 4, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.uni6_6, 5, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.uni6_7, 6, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.uni6_8, 7, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.uni7_1, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.uni7_2, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.uni7_3, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.uni7_4, 3, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.uni7_5, 4, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.uni7_6, 5, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.uni7_7, 6, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.uni7_8, 7, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.uni8_1, 0, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.uni8_2, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.uni8_3, 2, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.uni8_4, 3, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.uni8_5, 4, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.uni8_6, 5, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.uni8_7, 6, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.uni8_8, 7, 7)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(184, 27)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 8
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(568, 609)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'uni1_1
        '
        Me.uni1_1.BackColor = System.Drawing.Color.Gray
        Me.uni1_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_1.Location = New System.Drawing.Point(3, 3)
        Me.uni1_1.Name = "uni1_1"
        Me.uni1_1.Size = New System.Drawing.Size(64, 70)
        Me.uni1_1.TabIndex = 0
        Me.uni1_1.UseVisualStyleBackColor = False
        '
        'uni1_2
        '
        Me.uni1_2.BackColor = System.Drawing.Color.Gray
        Me.uni1_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_2.ForeColor = System.Drawing.Color.Black
        Me.uni1_2.Location = New System.Drawing.Point(73, 3)
        Me.uni1_2.Name = "uni1_2"
        Me.uni1_2.Size = New System.Drawing.Size(64, 70)
        Me.uni1_2.TabIndex = 1
        Me.uni1_2.UseVisualStyleBackColor = False
        '
        'uni1_3
        '
        Me.uni1_3.BackColor = System.Drawing.Color.Gray
        Me.uni1_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_3.ForeColor = System.Drawing.Color.Black
        Me.uni1_3.Location = New System.Drawing.Point(143, 3)
        Me.uni1_3.Name = "uni1_3"
        Me.uni1_3.Size = New System.Drawing.Size(64, 70)
        Me.uni1_3.TabIndex = 1
        Me.uni1_3.UseVisualStyleBackColor = False
        '
        'uni1_4
        '
        Me.uni1_4.BackColor = System.Drawing.Color.Gray
        Me.uni1_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_4.ForeColor = System.Drawing.Color.Black
        Me.uni1_4.Location = New System.Drawing.Point(213, 3)
        Me.uni1_4.Name = "uni1_4"
        Me.uni1_4.Size = New System.Drawing.Size(64, 70)
        Me.uni1_4.TabIndex = 1
        Me.uni1_4.UseVisualStyleBackColor = False
        '
        'uni1_5
        '
        Me.uni1_5.BackColor = System.Drawing.Color.Gray
        Me.uni1_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_5.ForeColor = System.Drawing.Color.Black
        Me.uni1_5.Location = New System.Drawing.Point(283, 3)
        Me.uni1_5.Name = "uni1_5"
        Me.uni1_5.Size = New System.Drawing.Size(64, 70)
        Me.uni1_5.TabIndex = 1
        Me.uni1_5.UseVisualStyleBackColor = False
        '
        'uni1_6
        '
        Me.uni1_6.BackColor = System.Drawing.Color.Gray
        Me.uni1_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_6.ForeColor = System.Drawing.Color.Black
        Me.uni1_6.Location = New System.Drawing.Point(353, 3)
        Me.uni1_6.Name = "uni1_6"
        Me.uni1_6.Size = New System.Drawing.Size(64, 70)
        Me.uni1_6.TabIndex = 1
        Me.uni1_6.UseVisualStyleBackColor = False
        '
        'uni1_7
        '
        Me.uni1_7.BackColor = System.Drawing.Color.Gray
        Me.uni1_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_7.ForeColor = System.Drawing.Color.Black
        Me.uni1_7.Location = New System.Drawing.Point(423, 3)
        Me.uni1_7.Name = "uni1_7"
        Me.uni1_7.Size = New System.Drawing.Size(67, 70)
        Me.uni1_7.TabIndex = 1
        Me.uni1_7.UseVisualStyleBackColor = False
        '
        'uni1_8
        '
        Me.uni1_8.BackColor = System.Drawing.Color.Gray
        Me.uni1_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni1_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni1_8.ForeColor = System.Drawing.Color.Black
        Me.uni1_8.Location = New System.Drawing.Point(496, 3)
        Me.uni1_8.Name = "uni1_8"
        Me.uni1_8.Size = New System.Drawing.Size(69, 70)
        Me.uni1_8.TabIndex = 1
        Me.uni1_8.UseVisualStyleBackColor = False
        '
        'uni2_1
        '
        Me.uni2_1.BackColor = System.Drawing.Color.Gray
        Me.uni2_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_1.ForeColor = System.Drawing.Color.Black
        Me.uni2_1.Location = New System.Drawing.Point(3, 79)
        Me.uni2_1.Name = "uni2_1"
        Me.uni2_1.Size = New System.Drawing.Size(64, 70)
        Me.uni2_1.TabIndex = 1
        Me.uni2_1.UseVisualStyleBackColor = False
        '
        'uni2_2
        '
        Me.uni2_2.BackColor = System.Drawing.Color.Gray
        Me.uni2_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_2.ForeColor = System.Drawing.Color.Black
        Me.uni2_2.Location = New System.Drawing.Point(73, 79)
        Me.uni2_2.Name = "uni2_2"
        Me.uni2_2.Size = New System.Drawing.Size(64, 70)
        Me.uni2_2.TabIndex = 1
        Me.uni2_2.UseVisualStyleBackColor = False
        '
        'uni2_3
        '
        Me.uni2_3.BackColor = System.Drawing.Color.Gray
        Me.uni2_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_3.ForeColor = System.Drawing.Color.Black
        Me.uni2_3.Location = New System.Drawing.Point(143, 79)
        Me.uni2_3.Name = "uni2_3"
        Me.uni2_3.Size = New System.Drawing.Size(64, 70)
        Me.uni2_3.TabIndex = 1
        Me.uni2_3.UseVisualStyleBackColor = False
        '
        'uni2_4
        '
        Me.uni2_4.BackColor = System.Drawing.Color.Gray
        Me.uni2_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_4.ForeColor = System.Drawing.Color.Black
        Me.uni2_4.Location = New System.Drawing.Point(213, 79)
        Me.uni2_4.Name = "uni2_4"
        Me.uni2_4.Size = New System.Drawing.Size(64, 70)
        Me.uni2_4.TabIndex = 1
        Me.uni2_4.UseVisualStyleBackColor = False
        '
        'uni2_5
        '
        Me.uni2_5.BackColor = System.Drawing.Color.Gray
        Me.uni2_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_5.ForeColor = System.Drawing.Color.Black
        Me.uni2_5.Location = New System.Drawing.Point(283, 79)
        Me.uni2_5.Name = "uni2_5"
        Me.uni2_5.Size = New System.Drawing.Size(64, 70)
        Me.uni2_5.TabIndex = 1
        Me.uni2_5.UseVisualStyleBackColor = False
        '
        'uni2_6
        '
        Me.uni2_6.BackColor = System.Drawing.Color.Gray
        Me.uni2_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_6.ForeColor = System.Drawing.Color.Black
        Me.uni2_6.Location = New System.Drawing.Point(353, 79)
        Me.uni2_6.Name = "uni2_6"
        Me.uni2_6.Size = New System.Drawing.Size(64, 70)
        Me.uni2_6.TabIndex = 1
        Me.uni2_6.UseVisualStyleBackColor = False
        '
        'uni2_7
        '
        Me.uni2_7.BackColor = System.Drawing.Color.Gray
        Me.uni2_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_7.ForeColor = System.Drawing.Color.Black
        Me.uni2_7.Location = New System.Drawing.Point(423, 79)
        Me.uni2_7.Name = "uni2_7"
        Me.uni2_7.Size = New System.Drawing.Size(67, 70)
        Me.uni2_7.TabIndex = 1
        Me.uni2_7.UseVisualStyleBackColor = False
        '
        'uni2_8
        '
        Me.uni2_8.BackColor = System.Drawing.Color.Gray
        Me.uni2_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni2_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni2_8.ForeColor = System.Drawing.Color.Black
        Me.uni2_8.Location = New System.Drawing.Point(496, 79)
        Me.uni2_8.Name = "uni2_8"
        Me.uni2_8.Size = New System.Drawing.Size(69, 70)
        Me.uni2_8.TabIndex = 1
        Me.uni2_8.UseVisualStyleBackColor = False
        '
        'uni3_1
        '
        Me.uni3_1.BackColor = System.Drawing.Color.Gray
        Me.uni3_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_1.ForeColor = System.Drawing.Color.Black
        Me.uni3_1.Location = New System.Drawing.Point(3, 155)
        Me.uni3_1.Name = "uni3_1"
        Me.uni3_1.Size = New System.Drawing.Size(64, 70)
        Me.uni3_1.TabIndex = 1
        Me.uni3_1.UseVisualStyleBackColor = False
        '
        'uni3_2
        '
        Me.uni3_2.BackColor = System.Drawing.Color.Gray
        Me.uni3_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_2.ForeColor = System.Drawing.Color.Black
        Me.uni3_2.Location = New System.Drawing.Point(73, 155)
        Me.uni3_2.Name = "uni3_2"
        Me.uni3_2.Size = New System.Drawing.Size(64, 70)
        Me.uni3_2.TabIndex = 1
        Me.uni3_2.UseVisualStyleBackColor = False
        '
        'uni3_3
        '
        Me.uni3_3.BackColor = System.Drawing.Color.Gray
        Me.uni3_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_3.ForeColor = System.Drawing.Color.Black
        Me.uni3_3.Location = New System.Drawing.Point(143, 155)
        Me.uni3_3.Name = "uni3_3"
        Me.uni3_3.Size = New System.Drawing.Size(64, 70)
        Me.uni3_3.TabIndex = 1
        Me.uni3_3.UseVisualStyleBackColor = False
        '
        'uni3_4
        '
        Me.uni3_4.BackColor = System.Drawing.Color.Gray
        Me.uni3_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_4.ForeColor = System.Drawing.Color.Black
        Me.uni3_4.Location = New System.Drawing.Point(213, 155)
        Me.uni3_4.Name = "uni3_4"
        Me.uni3_4.Size = New System.Drawing.Size(64, 70)
        Me.uni3_4.TabIndex = 1
        Me.uni3_4.UseVisualStyleBackColor = False
        '
        'uni3_5
        '
        Me.uni3_5.BackColor = System.Drawing.Color.Gray
        Me.uni3_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_5.ForeColor = System.Drawing.Color.Black
        Me.uni3_5.Location = New System.Drawing.Point(283, 155)
        Me.uni3_5.Name = "uni3_5"
        Me.uni3_5.Size = New System.Drawing.Size(64, 70)
        Me.uni3_5.TabIndex = 1
        Me.uni3_5.UseVisualStyleBackColor = False
        '
        'uni3_6
        '
        Me.uni3_6.BackColor = System.Drawing.Color.Gray
        Me.uni3_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_6.ForeColor = System.Drawing.Color.Black
        Me.uni3_6.Location = New System.Drawing.Point(353, 155)
        Me.uni3_6.Name = "uni3_6"
        Me.uni3_6.Size = New System.Drawing.Size(64, 70)
        Me.uni3_6.TabIndex = 1
        Me.uni3_6.UseVisualStyleBackColor = False
        '
        'uni3_7
        '
        Me.uni3_7.BackColor = System.Drawing.Color.Gray
        Me.uni3_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_7.ForeColor = System.Drawing.Color.Black
        Me.uni3_7.Location = New System.Drawing.Point(423, 155)
        Me.uni3_7.Name = "uni3_7"
        Me.uni3_7.Size = New System.Drawing.Size(67, 70)
        Me.uni3_7.TabIndex = 1
        Me.uni3_7.UseVisualStyleBackColor = False
        '
        'uni3_8
        '
        Me.uni3_8.BackColor = System.Drawing.Color.Gray
        Me.uni3_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni3_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni3_8.ForeColor = System.Drawing.Color.Black
        Me.uni3_8.Location = New System.Drawing.Point(496, 155)
        Me.uni3_8.Name = "uni3_8"
        Me.uni3_8.Size = New System.Drawing.Size(69, 70)
        Me.uni3_8.TabIndex = 1
        Me.uni3_8.UseVisualStyleBackColor = False
        '
        'uni4_1
        '
        Me.uni4_1.BackColor = System.Drawing.Color.Gray
        Me.uni4_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_1.ForeColor = System.Drawing.Color.Black
        Me.uni4_1.Location = New System.Drawing.Point(3, 231)
        Me.uni4_1.Name = "uni4_1"
        Me.uni4_1.Size = New System.Drawing.Size(64, 70)
        Me.uni4_1.TabIndex = 1
        Me.uni4_1.UseVisualStyleBackColor = False
        '
        'uni4_2
        '
        Me.uni4_2.BackColor = System.Drawing.Color.Gray
        Me.uni4_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_2.ForeColor = System.Drawing.Color.Black
        Me.uni4_2.Location = New System.Drawing.Point(73, 231)
        Me.uni4_2.Name = "uni4_2"
        Me.uni4_2.Size = New System.Drawing.Size(64, 70)
        Me.uni4_2.TabIndex = 1
        Me.uni4_2.UseVisualStyleBackColor = False
        '
        'uni4_3
        '
        Me.uni4_3.BackColor = System.Drawing.Color.Gray
        Me.uni4_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_3.ForeColor = System.Drawing.Color.Black
        Me.uni4_3.Location = New System.Drawing.Point(143, 231)
        Me.uni4_3.Name = "uni4_3"
        Me.uni4_3.Size = New System.Drawing.Size(64, 70)
        Me.uni4_3.TabIndex = 1
        Me.uni4_3.UseVisualStyleBackColor = False
        '
        'uni4_4
        '
        Me.uni4_4.BackColor = System.Drawing.Color.Gray
        Me.uni4_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_4.ForeColor = System.Drawing.Color.Black
        Me.uni4_4.Location = New System.Drawing.Point(213, 231)
        Me.uni4_4.Name = "uni4_4"
        Me.uni4_4.Size = New System.Drawing.Size(64, 70)
        Me.uni4_4.TabIndex = 1
        Me.uni4_4.UseVisualStyleBackColor = False
        '
        'uni4_5
        '
        Me.uni4_5.BackColor = System.Drawing.Color.Gray
        Me.uni4_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_5.ForeColor = System.Drawing.Color.Black
        Me.uni4_5.Location = New System.Drawing.Point(283, 231)
        Me.uni4_5.Name = "uni4_5"
        Me.uni4_5.Size = New System.Drawing.Size(64, 70)
        Me.uni4_5.TabIndex = 1
        Me.uni4_5.UseVisualStyleBackColor = False
        '
        'uni4_6
        '
        Me.uni4_6.BackColor = System.Drawing.Color.Gray
        Me.uni4_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_6.ForeColor = System.Drawing.Color.Black
        Me.uni4_6.Location = New System.Drawing.Point(353, 231)
        Me.uni4_6.Name = "uni4_6"
        Me.uni4_6.Size = New System.Drawing.Size(64, 70)
        Me.uni4_6.TabIndex = 1
        Me.uni4_6.UseVisualStyleBackColor = False
        '
        'uni4_7
        '
        Me.uni4_7.BackColor = System.Drawing.Color.Gray
        Me.uni4_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_7.ForeColor = System.Drawing.Color.Black
        Me.uni4_7.Location = New System.Drawing.Point(423, 231)
        Me.uni4_7.Name = "uni4_7"
        Me.uni4_7.Size = New System.Drawing.Size(67, 70)
        Me.uni4_7.TabIndex = 1
        Me.uni4_7.UseVisualStyleBackColor = False
        '
        'uni4_8
        '
        Me.uni4_8.BackColor = System.Drawing.Color.Gray
        Me.uni4_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni4_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni4_8.ForeColor = System.Drawing.Color.Black
        Me.uni4_8.Location = New System.Drawing.Point(496, 231)
        Me.uni4_8.Name = "uni4_8"
        Me.uni4_8.Size = New System.Drawing.Size(69, 70)
        Me.uni4_8.TabIndex = 1
        Me.uni4_8.UseVisualStyleBackColor = False
        '
        'uni5_1
        '
        Me.uni5_1.BackColor = System.Drawing.Color.Gray
        Me.uni5_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_1.ForeColor = System.Drawing.Color.Black
        Me.uni5_1.Location = New System.Drawing.Point(3, 307)
        Me.uni5_1.Name = "uni5_1"
        Me.uni5_1.Size = New System.Drawing.Size(64, 70)
        Me.uni5_1.TabIndex = 1
        Me.uni5_1.UseVisualStyleBackColor = False
        '
        'uni5_2
        '
        Me.uni5_2.BackColor = System.Drawing.Color.Gray
        Me.uni5_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_2.ForeColor = System.Drawing.Color.Black
        Me.uni5_2.Location = New System.Drawing.Point(73, 307)
        Me.uni5_2.Name = "uni5_2"
        Me.uni5_2.Size = New System.Drawing.Size(64, 70)
        Me.uni5_2.TabIndex = 1
        Me.uni5_2.UseVisualStyleBackColor = False
        '
        'uni5_3
        '
        Me.uni5_3.BackColor = System.Drawing.Color.Gray
        Me.uni5_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_3.ForeColor = System.Drawing.Color.Black
        Me.uni5_3.Location = New System.Drawing.Point(143, 307)
        Me.uni5_3.Name = "uni5_3"
        Me.uni5_3.Size = New System.Drawing.Size(64, 70)
        Me.uni5_3.TabIndex = 1
        Me.uni5_3.UseVisualStyleBackColor = False
        '
        'uni5_4
        '
        Me.uni5_4.BackColor = System.Drawing.Color.Gray
        Me.uni5_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_4.ForeColor = System.Drawing.Color.Black
        Me.uni5_4.Location = New System.Drawing.Point(213, 307)
        Me.uni5_4.Name = "uni5_4"
        Me.uni5_4.Size = New System.Drawing.Size(64, 70)
        Me.uni5_4.TabIndex = 1
        Me.uni5_4.UseVisualStyleBackColor = False
        '
        'uni5_5
        '
        Me.uni5_5.BackColor = System.Drawing.Color.Gray
        Me.uni5_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_5.ForeColor = System.Drawing.Color.Black
        Me.uni5_5.Location = New System.Drawing.Point(283, 307)
        Me.uni5_5.Name = "uni5_5"
        Me.uni5_5.Size = New System.Drawing.Size(64, 70)
        Me.uni5_5.TabIndex = 1
        Me.uni5_5.UseVisualStyleBackColor = False
        '
        'uni5_6
        '
        Me.uni5_6.BackColor = System.Drawing.Color.Gray
        Me.uni5_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_6.ForeColor = System.Drawing.Color.Black
        Me.uni5_6.Location = New System.Drawing.Point(353, 307)
        Me.uni5_6.Name = "uni5_6"
        Me.uni5_6.Size = New System.Drawing.Size(64, 70)
        Me.uni5_6.TabIndex = 1
        Me.uni5_6.UseVisualStyleBackColor = False
        '
        'uni5_7
        '
        Me.uni5_7.BackColor = System.Drawing.Color.Gray
        Me.uni5_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_7.ForeColor = System.Drawing.Color.Black
        Me.uni5_7.Location = New System.Drawing.Point(423, 307)
        Me.uni5_7.Name = "uni5_7"
        Me.uni5_7.Size = New System.Drawing.Size(67, 70)
        Me.uni5_7.TabIndex = 1
        Me.uni5_7.UseVisualStyleBackColor = False
        '
        'uni5_8
        '
        Me.uni5_8.BackColor = System.Drawing.Color.Gray
        Me.uni5_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni5_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni5_8.ForeColor = System.Drawing.Color.Black
        Me.uni5_8.Location = New System.Drawing.Point(496, 307)
        Me.uni5_8.Name = "uni5_8"
        Me.uni5_8.Size = New System.Drawing.Size(69, 70)
        Me.uni5_8.TabIndex = 1
        Me.uni5_8.UseVisualStyleBackColor = False
        '
        'uni6_1
        '
        Me.uni6_1.BackColor = System.Drawing.Color.Gray
        Me.uni6_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_1.ForeColor = System.Drawing.Color.Black
        Me.uni6_1.Location = New System.Drawing.Point(3, 383)
        Me.uni6_1.Name = "uni6_1"
        Me.uni6_1.Size = New System.Drawing.Size(64, 70)
        Me.uni6_1.TabIndex = 1
        Me.uni6_1.UseVisualStyleBackColor = False
        '
        'uni6_2
        '
        Me.uni6_2.BackColor = System.Drawing.Color.Gray
        Me.uni6_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_2.ForeColor = System.Drawing.Color.Black
        Me.uni6_2.Location = New System.Drawing.Point(73, 383)
        Me.uni6_2.Name = "uni6_2"
        Me.uni6_2.Size = New System.Drawing.Size(64, 70)
        Me.uni6_2.TabIndex = 1
        Me.uni6_2.UseVisualStyleBackColor = False
        '
        'uni6_3
        '
        Me.uni6_3.BackColor = System.Drawing.Color.Gray
        Me.uni6_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_3.ForeColor = System.Drawing.Color.Black
        Me.uni6_3.Location = New System.Drawing.Point(143, 383)
        Me.uni6_3.Name = "uni6_3"
        Me.uni6_3.Size = New System.Drawing.Size(64, 70)
        Me.uni6_3.TabIndex = 1
        Me.uni6_3.UseVisualStyleBackColor = False
        '
        'uni6_4
        '
        Me.uni6_4.BackColor = System.Drawing.Color.Gray
        Me.uni6_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_4.ForeColor = System.Drawing.Color.Black
        Me.uni6_4.Location = New System.Drawing.Point(213, 383)
        Me.uni6_4.Name = "uni6_4"
        Me.uni6_4.Size = New System.Drawing.Size(64, 70)
        Me.uni6_4.TabIndex = 1
        Me.uni6_4.UseVisualStyleBackColor = False
        '
        'uni6_5
        '
        Me.uni6_5.BackColor = System.Drawing.Color.Gray
        Me.uni6_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_5.ForeColor = System.Drawing.Color.Black
        Me.uni6_5.Location = New System.Drawing.Point(283, 383)
        Me.uni6_5.Name = "uni6_5"
        Me.uni6_5.Size = New System.Drawing.Size(64, 70)
        Me.uni6_5.TabIndex = 1
        Me.uni6_5.UseVisualStyleBackColor = False
        '
        'uni6_6
        '
        Me.uni6_6.BackColor = System.Drawing.Color.Gray
        Me.uni6_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_6.ForeColor = System.Drawing.Color.Black
        Me.uni6_6.Location = New System.Drawing.Point(353, 383)
        Me.uni6_6.Name = "uni6_6"
        Me.uni6_6.Size = New System.Drawing.Size(64, 70)
        Me.uni6_6.TabIndex = 1
        Me.uni6_6.UseVisualStyleBackColor = False
        '
        'uni6_7
        '
        Me.uni6_7.BackColor = System.Drawing.Color.Gray
        Me.uni6_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_7.ForeColor = System.Drawing.Color.Black
        Me.uni6_7.Location = New System.Drawing.Point(423, 383)
        Me.uni6_7.Name = "uni6_7"
        Me.uni6_7.Size = New System.Drawing.Size(67, 70)
        Me.uni6_7.TabIndex = 1
        Me.uni6_7.UseVisualStyleBackColor = False
        '
        'uni6_8
        '
        Me.uni6_8.BackColor = System.Drawing.Color.Gray
        Me.uni6_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni6_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni6_8.ForeColor = System.Drawing.Color.Black
        Me.uni6_8.Location = New System.Drawing.Point(496, 383)
        Me.uni6_8.Name = "uni6_8"
        Me.uni6_8.Size = New System.Drawing.Size(69, 70)
        Me.uni6_8.TabIndex = 1
        Me.uni6_8.UseVisualStyleBackColor = False
        '
        'uni7_1
        '
        Me.uni7_1.BackColor = System.Drawing.Color.Gray
        Me.uni7_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_1.ForeColor = System.Drawing.Color.Black
        Me.uni7_1.Location = New System.Drawing.Point(3, 459)
        Me.uni7_1.Name = "uni7_1"
        Me.uni7_1.Size = New System.Drawing.Size(64, 70)
        Me.uni7_1.TabIndex = 1
        Me.uni7_1.UseVisualStyleBackColor = False
        '
        'uni7_2
        '
        Me.uni7_2.BackColor = System.Drawing.Color.Gray
        Me.uni7_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_2.ForeColor = System.Drawing.Color.Black
        Me.uni7_2.Location = New System.Drawing.Point(73, 459)
        Me.uni7_2.Name = "uni7_2"
        Me.uni7_2.Size = New System.Drawing.Size(64, 70)
        Me.uni7_2.TabIndex = 1
        Me.uni7_2.UseVisualStyleBackColor = False
        '
        'uni7_3
        '
        Me.uni7_3.BackColor = System.Drawing.Color.Gray
        Me.uni7_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_3.ForeColor = System.Drawing.Color.Black
        Me.uni7_3.Location = New System.Drawing.Point(143, 459)
        Me.uni7_3.Name = "uni7_3"
        Me.uni7_3.Size = New System.Drawing.Size(64, 70)
        Me.uni7_3.TabIndex = 1
        Me.uni7_3.UseVisualStyleBackColor = False
        '
        'uni7_4
        '
        Me.uni7_4.BackColor = System.Drawing.Color.Gray
        Me.uni7_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_4.ForeColor = System.Drawing.Color.Black
        Me.uni7_4.Location = New System.Drawing.Point(213, 459)
        Me.uni7_4.Name = "uni7_4"
        Me.uni7_4.Size = New System.Drawing.Size(64, 70)
        Me.uni7_4.TabIndex = 1
        Me.uni7_4.UseVisualStyleBackColor = False
        '
        'uni7_5
        '
        Me.uni7_5.BackColor = System.Drawing.Color.Gray
        Me.uni7_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_5.ForeColor = System.Drawing.Color.Black
        Me.uni7_5.Location = New System.Drawing.Point(283, 459)
        Me.uni7_5.Name = "uni7_5"
        Me.uni7_5.Size = New System.Drawing.Size(64, 70)
        Me.uni7_5.TabIndex = 1
        Me.uni7_5.UseVisualStyleBackColor = False
        '
        'uni7_6
        '
        Me.uni7_6.BackColor = System.Drawing.Color.Gray
        Me.uni7_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_6.ForeColor = System.Drawing.Color.Black
        Me.uni7_6.Location = New System.Drawing.Point(353, 459)
        Me.uni7_6.Name = "uni7_6"
        Me.uni7_6.Size = New System.Drawing.Size(64, 70)
        Me.uni7_6.TabIndex = 1
        Me.uni7_6.UseVisualStyleBackColor = False
        '
        'uni7_7
        '
        Me.uni7_7.BackColor = System.Drawing.Color.Gray
        Me.uni7_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_7.ForeColor = System.Drawing.Color.Black
        Me.uni7_7.Location = New System.Drawing.Point(423, 459)
        Me.uni7_7.Name = "uni7_7"
        Me.uni7_7.Size = New System.Drawing.Size(67, 70)
        Me.uni7_7.TabIndex = 1
        Me.uni7_7.UseVisualStyleBackColor = False
        '
        'uni7_8
        '
        Me.uni7_8.BackColor = System.Drawing.Color.Gray
        Me.uni7_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni7_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni7_8.ForeColor = System.Drawing.Color.Black
        Me.uni7_8.Location = New System.Drawing.Point(496, 459)
        Me.uni7_8.Name = "uni7_8"
        Me.uni7_8.Size = New System.Drawing.Size(69, 70)
        Me.uni7_8.TabIndex = 1
        Me.uni7_8.UseVisualStyleBackColor = False
        '
        'uni8_1
        '
        Me.uni8_1.BackColor = System.Drawing.Color.Gray
        Me.uni8_1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_1.ForeColor = System.Drawing.Color.Black
        Me.uni8_1.Location = New System.Drawing.Point(3, 535)
        Me.uni8_1.Name = "uni8_1"
        Me.uni8_1.Size = New System.Drawing.Size(64, 71)
        Me.uni8_1.TabIndex = 1
        Me.uni8_1.UseVisualStyleBackColor = False
        '
        'uni8_2
        '
        Me.uni8_2.BackColor = System.Drawing.Color.Gray
        Me.uni8_2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_2.ForeColor = System.Drawing.Color.Black
        Me.uni8_2.Location = New System.Drawing.Point(73, 535)
        Me.uni8_2.Name = "uni8_2"
        Me.uni8_2.Size = New System.Drawing.Size(64, 71)
        Me.uni8_2.TabIndex = 1
        Me.uni8_2.UseVisualStyleBackColor = False
        '
        'uni8_3
        '
        Me.uni8_3.BackColor = System.Drawing.Color.Gray
        Me.uni8_3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_3.ForeColor = System.Drawing.Color.Black
        Me.uni8_3.Location = New System.Drawing.Point(143, 535)
        Me.uni8_3.Name = "uni8_3"
        Me.uni8_3.Size = New System.Drawing.Size(64, 71)
        Me.uni8_3.TabIndex = 1
        Me.uni8_3.UseVisualStyleBackColor = False
        '
        'uni8_4
        '
        Me.uni8_4.BackColor = System.Drawing.Color.Gray
        Me.uni8_4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_4.ForeColor = System.Drawing.Color.Black
        Me.uni8_4.Location = New System.Drawing.Point(213, 535)
        Me.uni8_4.Name = "uni8_4"
        Me.uni8_4.Size = New System.Drawing.Size(64, 71)
        Me.uni8_4.TabIndex = 1
        Me.uni8_4.UseVisualStyleBackColor = False
        '
        'uni8_5
        '
        Me.uni8_5.BackColor = System.Drawing.Color.Gray
        Me.uni8_5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_5.ForeColor = System.Drawing.Color.Black
        Me.uni8_5.Location = New System.Drawing.Point(283, 535)
        Me.uni8_5.Name = "uni8_5"
        Me.uni8_5.Size = New System.Drawing.Size(64, 71)
        Me.uni8_5.TabIndex = 1
        Me.uni8_5.UseVisualStyleBackColor = False
        '
        'uni8_6
        '
        Me.uni8_6.BackColor = System.Drawing.Color.Gray
        Me.uni8_6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_6.ForeColor = System.Drawing.Color.Black
        Me.uni8_6.Location = New System.Drawing.Point(353, 535)
        Me.uni8_6.Name = "uni8_6"
        Me.uni8_6.Size = New System.Drawing.Size(64, 71)
        Me.uni8_6.TabIndex = 1
        Me.uni8_6.UseVisualStyleBackColor = False
        '
        'uni8_7
        '
        Me.uni8_7.BackColor = System.Drawing.Color.Gray
        Me.uni8_7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_7.ForeColor = System.Drawing.Color.Black
        Me.uni8_7.Location = New System.Drawing.Point(423, 535)
        Me.uni8_7.Name = "uni8_7"
        Me.uni8_7.Size = New System.Drawing.Size(67, 71)
        Me.uni8_7.TabIndex = 1
        Me.uni8_7.UseVisualStyleBackColor = False
        '
        'uni8_8
        '
        Me.uni8_8.BackColor = System.Drawing.Color.Gray
        Me.uni8_8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.uni8_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uni8_8.ForeColor = System.Drawing.Color.Black
        Me.uni8_8.Location = New System.Drawing.Point(496, 535)
        Me.uni8_8.Name = "uni8_8"
        Me.uni8_8.Size = New System.Drawing.Size(69, 71)
        Me.uni8_8.TabIndex = 1
        Me.uni8_8.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightGray
        Me.GroupBox1.Controls.Add(Me.rblededit)
        Me.GroupBox1.Controls.Add(Me.rbEditmode)
        Me.GroupBox1.Controls.Add(Me.rbPlaymode)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(3, 425)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(172, 116)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Mode"
        '
        'rblededit
        '
        Me.rblededit.AutoSize = True
        Me.rblededit.Location = New System.Drawing.Point(17, 64)
        Me.rblededit.Name = "rblededit"
        Me.rblededit.Size = New System.Drawing.Size(77, 16)
        Me.rblededit.TabIndex = 2
        Me.rblededit.Text = "Edit(LED)"
        Me.rblededit.UseVisualStyleBackColor = True
        '
        'rbEditmode
        '
        Me.rbEditmode.AutoSize = True
        Me.rbEditmode.Location = New System.Drawing.Point(16, 42)
        Me.rbEditmode.Name = "rbEditmode"
        Me.rbEditmode.Size = New System.Drawing.Size(90, 16)
        Me.rbEditmode.TabIndex = 1
        Me.rbEditmode.Text = "Edit(Sound)"
        Me.rbEditmode.UseVisualStyleBackColor = True
        '
        'rbPlaymode
        '
        Me.rbPlaymode.AutoSize = True
        Me.rbPlaymode.Checked = True
        Me.rbPlaymode.Location = New System.Drawing.Point(16, 20)
        Me.rbPlaymode.Name = "rbPlaymode"
        Me.rbPlaymode.Size = New System.Drawing.Size(48, 16)
        Me.rbPlaymode.TabIndex = 0
        Me.rbPlaymode.TabStop = True
        Me.rbPlaymode.Text = "Test"
        Me.rbPlaymode.UseVisualStyleBackColor = True
        '
        'menuMainProj
        '
        Me.menuMainProj.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.menuMainProj.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.TestNReleaseToolStripMenuItem, Me.HelpToolStripMenuItem, Me.SettingToolStripMenuItem})
        Me.menuMainProj.Location = New System.Drawing.Point(0, 0)
        Me.menuMainProj.Name = "menuMainProj"
        Me.menuMainProj.Size = New System.Drawing.Size(907, 24)
        Me.menuMainProj.TabIndex = 3
        Me.menuMainProj.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenProjectToolStripMenuItem, Me.DeleteProjectToolStripMenuItem, Me.SaveProjectToolStripMenuItem, Me.ToolStripSeparator2, Me.Mp3ToWavConverterToolStripMenuItem, Me.ToolStripSeparator3, Me.UploadToUniPackWWToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'OpenProjectToolStripMenuItem
        '
        Me.OpenProjectToolStripMenuItem.Name = "OpenProjectToolStripMenuItem"
        Me.OpenProjectToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.OpenProjectToolStripMenuItem.Text = "Open Project"
        '
        'DeleteProjectToolStripMenuItem
        '
        Me.DeleteProjectToolStripMenuItem.Name = "DeleteProjectToolStripMenuItem"
        Me.DeleteProjectToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.DeleteProjectToolStripMenuItem.Text = "Delete Project"
        '
        'SaveProjectToolStripMenuItem
        '
        Me.SaveProjectToolStripMenuItem.Name = "SaveProjectToolStripMenuItem"
        Me.SaveProjectToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.SaveProjectToolStripMenuItem.Text = "Save Project"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(194, 6)
        '
        'Mp3ToWavConverterToolStripMenuItem
        '
        Me.Mp3ToWavConverterToolStripMenuItem.Name = "Mp3ToWavConverterToolStripMenuItem"
        Me.Mp3ToWavConverterToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.Mp3ToWavConverterToolStripMenuItem.Text = "Mp3 to Wav Converter"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(194, 6)
        '
        'UploadToUniPackWWToolStripMenuItem
        '
        Me.UploadToUniPackWWToolStripMenuItem.Name = "UploadToUniPackWWToolStripMenuItem"
        Me.UploadToUniPackWWToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.UploadToUniPackWWToolStripMenuItem.Text = "Upload to UniPackWW"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SoundsToolStripMenuItem, Me.SoundCutterToolStripMenuItem, Me.KeySoundTextEditorToolStripMenuItem, Me.AutoPlayTextEditorToolStripMenuItem, Me.ledisableenable})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'SoundsToolStripMenuItem
        '
        Me.SoundsToolStripMenuItem.Name = "SoundsToolStripMenuItem"
        Me.SoundsToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.SoundsToolStripMenuItem.Text = "Sounds"
        '
        'SoundCutterToolStripMenuItem
        '
        Me.SoundCutterToolStripMenuItem.Name = "SoundCutterToolStripMenuItem"
        Me.SoundCutterToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.SoundCutterToolStripMenuItem.Text = "Sound Cutter"
        Me.SoundCutterToolStripMenuItem.Visible = False
        '
        'KeySoundTextEditorToolStripMenuItem
        '
        Me.KeySoundTextEditorToolStripMenuItem.Name = "KeySoundTextEditorToolStripMenuItem"
        Me.KeySoundTextEditorToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.KeySoundTextEditorToolStripMenuItem.Text = "keySound Text Editor"
        '
        'AutoPlayTextEditorToolStripMenuItem
        '
        Me.AutoPlayTextEditorToolStripMenuItem.Name = "AutoPlayTextEditorToolStripMenuItem"
        Me.AutoPlayTextEditorToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.AutoPlayTextEditorToolStripMenuItem.Text = "autoPlay Text Editor"
        '
        'ledisableenable
        '
        Me.ledisableenable.Name = "ledisableenable"
        Me.ledisableenable.Size = New System.Drawing.Size(188, 22)
        Me.ledisableenable.Text = "LED En/Dis"
        '
        'TestNReleaseToolStripMenuItem
        '
        Me.TestNReleaseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AutoPlayBetaToolStripMenuItem, Me.AutoPlayControlerToolStripMenuItem, Me.ToolStripSeparator1, Me.PushToDeviceToolStripMenuItem, Me.ConnectMidiToolStripMenuItem})
        Me.TestNReleaseToolStripMenuItem.Name = "TestNReleaseToolStripMenuItem"
        Me.TestNReleaseToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.TestNReleaseToolStripMenuItem.Text = "Test"
        '
        'AutoPlayBetaToolStripMenuItem
        '
        Me.AutoPlayBetaToolStripMenuItem.Name = "AutoPlayBetaToolStripMenuItem"
        Me.AutoPlayBetaToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AutoPlayBetaToolStripMenuItem.Text = "Auto Play (Beta)"
        '
        'AutoPlayControlerToolStripMenuItem
        '
        Me.AutoPlayControlerToolStripMenuItem.Name = "AutoPlayControlerToolStripMenuItem"
        Me.AutoPlayControlerToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AutoPlayControlerToolStripMenuItem.Text = "Auto Play Controler"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(177, 6)
        '
        'PushToDeviceToolStripMenuItem
        '
        Me.PushToDeviceToolStripMenuItem.Name = "PushToDeviceToolStripMenuItem"
        Me.PushToDeviceToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.PushToDeviceToolStripMenuItem.Text = "Push to Device"
        '
        'ConnectMidiToolStripMenuItem
        '
        Me.ConnectMidiToolStripMenuItem.Name = "ConnectMidiToolStripMenuItem"
        Me.ConnectMidiToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ConnectMidiToolStripMenuItem.Text = "connect midi"
        Me.ConnectMidiToolStripMenuItem.Visible = False
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InformationToolStripMenuItem, Me.HelpToolStripMenuItem1, Me.CreditToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'InformationToolStripMenuItem
        '
        Me.InformationToolStripMenuItem.Name = "InformationToolStripMenuItem"
        Me.InformationToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.InformationToolStripMenuItem.Text = "Information"
        Me.InformationToolStripMenuItem.Visible = False
        '
        'HelpToolStripMenuItem1
        '
        Me.HelpToolStripMenuItem1.Name = "HelpToolStripMenuItem1"
        Me.HelpToolStripMenuItem1.Size = New System.Drawing.Size(137, 22)
        Me.HelpToolStripMenuItem1.Text = "Help"
        Me.HelpToolStripMenuItem1.Visible = False
        '
        'CreditToolStripMenuItem
        '
        Me.CreditToolStripMenuItem.Name = "CreditToolStripMenuItem"
        Me.CreditToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.CreditToolStripMenuItem.Text = "Credit"
        '
        'SettingToolStripMenuItem
        '
        Me.SettingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenSettingToolStripMenuItem, Me.RestoreDefaultWindowSizeToolStripMenuItem, Me.TestMakeCrashToolStripMenuItem})
        Me.SettingToolStripMenuItem.Name = "SettingToolStripMenuItem"
        Me.SettingToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.SettingToolStripMenuItem.Text = "Setting"
        '
        'OpenSettingToolStripMenuItem
        '
        Me.OpenSettingToolStripMenuItem.Name = "OpenSettingToolStripMenuItem"
        Me.OpenSettingToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.OpenSettingToolStripMenuItem.Text = "Open Setting"
        '
        'RestoreDefaultWindowSizeToolStripMenuItem
        '
        Me.RestoreDefaultWindowSizeToolStripMenuItem.Name = "RestoreDefaultWindowSizeToolStripMenuItem"
        Me.RestoreDefaultWindowSizeToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.RestoreDefaultWindowSizeToolStripMenuItem.Text = "Restore Default Window Size"
        '
        'TestMakeCrashToolStripMenuItem
        '
        Me.TestMakeCrashToolStripMenuItem.Name = "TestMakeCrashToolStripMenuItem"
        Me.TestMakeCrashToolStripMenuItem.Size = New System.Drawing.Size(230, 22)
        Me.TestMakeCrashToolStripMenuItem.Text = "Test: Make Crash"
        Me.TestMakeCrashToolStripMenuItem.Visible = False
        '
        'groupUniPackInfo
        '
        Me.groupUniPackInfo.BackColor = System.Drawing.Color.LightGray
        Me.groupUniPackInfo.Controls.Add(Me.Label7)
        Me.groupUniPackInfo.Controls.Add(Me.labelInfSave)
        Me.groupUniPackInfo.Controls.Add(Me.tbPackChains)
        Me.groupUniPackInfo.Controls.Add(Me.Label5)
        Me.groupUniPackInfo.Controls.Add(Me.Label3)
        Me.groupUniPackInfo.Controls.Add(Me.Label4)
        Me.groupUniPackInfo.Controls.Add(Me.Label2)
        Me.groupUniPackInfo.Controls.Add(Me.Label1)
        Me.groupUniPackInfo.Controls.Add(Me.tbPackAuthor)
        Me.groupUniPackInfo.Controls.Add(Me.tbPackDirInfo)
        Me.groupUniPackInfo.Controls.Add(Me.tbPackName)
        Me.groupUniPackInfo.Controls.Add(Me.btnSavePackInfo)
        Me.groupUniPackInfo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.groupUniPackInfo.Location = New System.Drawing.Point(3, 3)
        Me.groupUniPackInfo.Name = "groupUniPackInfo"
        Me.groupUniPackInfo.Size = New System.Drawing.Size(172, 416)
        Me.groupUniPackInfo.TabIndex = 2
        Me.groupUniPackInfo.TabStop = False
        Me.groupUniPackInfo.Text = "UniPack Information"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(2, 307)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(173, 48)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "*Tip:This Pad won't tell you" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "any LED Errors! You must" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "check it with LED Editor." & _
    "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Also, UniPad ignores it, too!)"
        '
        'labelInfSave
        '
        Me.labelInfSave.AutoSize = True
        Me.labelInfSave.Location = New System.Drawing.Point(81, 195)
        Me.labelInfSave.Name = "labelInfSave"
        Me.labelInfSave.Size = New System.Drawing.Size(55, 12)
        Me.labelInfSave.TabIndex = 9
        Me.labelInfSave.Text = "Saving..."
        Me.labelInfSave.Visible = False
        '
        'tbPackChains
        '
        Me.tbPackChains.Location = New System.Drawing.Point(8, 192)
        Me.tbPackChains.Name = "tbPackChains"
        Me.tbPackChains.ReadOnly = True
        Me.tbPackChains.Size = New System.Drawing.Size(52, 21)
        Me.tbPackChains.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 177)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 12)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Chains"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 229)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 24)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "*This is not OFFICIAL" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "software by Kim JS."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 127)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 12)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Path of UniPack"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 12)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Pack Author"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 12)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Pack Name"
        '
        'tbPackAuthor
        '
        Me.tbPackAuthor.Location = New System.Drawing.Point(8, 90)
        Me.tbPackAuthor.Name = "tbPackAuthor"
        Me.tbPackAuthor.Size = New System.Drawing.Size(157, 21)
        Me.tbPackAuthor.TabIndex = 4
        '
        'tbPackDirInfo
        '
        Me.tbPackDirInfo.Location = New System.Drawing.Point(8, 142)
        Me.tbPackDirInfo.Name = "tbPackDirInfo"
        Me.tbPackDirInfo.ReadOnly = True
        Me.tbPackDirInfo.Size = New System.Drawing.Size(157, 21)
        Me.tbPackDirInfo.TabIndex = 4
        '
        'tbPackName
        '
        Me.tbPackName.Location = New System.Drawing.Point(8, 41)
        Me.tbPackName.Name = "tbPackName"
        Me.tbPackName.Size = New System.Drawing.Size(157, 21)
        Me.tbPackName.TabIndex = 4
        '
        'btnSavePackInfo
        '
        Me.btnSavePackInfo.Location = New System.Drawing.Point(17, 264)
        Me.btnSavePackInfo.Name = "btnSavePackInfo"
        Me.btnSavePackInfo.Size = New System.Drawing.Size(123, 20)
        Me.btnSavePackInfo.TabIndex = 2
        Me.btnSavePackInfo.Text = "Save Information"
        Me.btnSavePackInfo.UseVisualStyleBackColor = True
        '
        'listChain
        '
        Me.listChain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.listChain.Font = New System.Drawing.Font("맑은 고딕", 20.0!)
        Me.listChain.FormattingEnabled = True
        Me.listChain.ItemHeight = 37
        Me.listChain.Location = New System.Drawing.Point(3, 15)
        Me.listChain.Name = "listChain"
        Me.listChain.Size = New System.Drawing.Size(140, 448)
        Me.listChain.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 12)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "UniPack Chains"
        '
        'Button1
        '
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Button1.Location = New System.Drawing.Point(3, 498)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(140, 49)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Add Chain"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Button2.Location = New System.Drawing.Point(3, 553)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(140, 23)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "Delete Chain"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Label8.Location = New System.Drawing.Point(3, 579)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(140, 36)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "*Tip: You must save" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "any sounds to save" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "new chain."
        '
        'btnFlushLEDColor
        '
        Me.btnFlushLEDColor.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnFlushLEDColor.Location = New System.Drawing.Point(3, 589)
        Me.btnFlushLEDColor.Name = "btnFlushLEDColor"
        Me.btnFlushLEDColor.Size = New System.Drawing.Size(172, 23)
        Me.btnFlushLEDColor.TabIndex = 15
        Me.btnFlushLEDColor.Text = "Flush LED Board"
        Me.btnFlushLEDColor.UseVisualStyleBackColor = True
        '
        'btnFlushSound
        '
        Me.btnFlushSound.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnFlushSound.Location = New System.Drawing.Point(3, 553)
        Me.btnFlushSound.Name = "btnFlushSound"
        Me.btnFlushSound.Size = New System.Drawing.Size(172, 23)
        Me.btnFlushSound.TabIndex = 15
        Me.btnFlushSound.Text = "Flush Multi Mapper"
        Me.btnFlushSound.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.groupUniPackInfo, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnFlushLEDColor, 0, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.btnFlushSound, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.GroupBox1, 0, 1)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 24)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 4
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.61105!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.38895!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(178, 615)
        Me.TableLayoutPanel2.TabIndex = 16
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Label6, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.listChain, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label8, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.Button1, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Button2, 0, 3)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(761, 24)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 5
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(146, 615)
        Me.TableLayoutPanel3.TabIndex = 17
        '
        'MainProjectLoader
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGray
        Me.ClientSize = New System.Drawing.Size(907, 639)
        Me.Controls.Add(Me.TableLayoutPanel3)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.menuMainProj)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "MainProjectLoader"
        Me.Text = "UniPack Loader Main"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.menuMainProj.ResumeLayout(False)
        Me.menuMainProj.PerformLayout()
        Me.groupUniPackInfo.ResumeLayout(False)
        Me.groupUniPackInfo.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents uni1_1 As System.Windows.Forms.Button
    Friend WithEvents uni1_2 As System.Windows.Forms.Button
    Friend WithEvents uni1_3 As System.Windows.Forms.Button
    Friend WithEvents uni1_4 As System.Windows.Forms.Button
    Friend WithEvents uni1_5 As System.Windows.Forms.Button
    Friend WithEvents uni1_6 As System.Windows.Forms.Button
    Friend WithEvents uni1_7 As System.Windows.Forms.Button
    Friend WithEvents uni1_8 As System.Windows.Forms.Button
    Friend WithEvents uni2_1 As System.Windows.Forms.Button
    Friend WithEvents uni2_2 As System.Windows.Forms.Button
    Friend WithEvents uni2_3 As System.Windows.Forms.Button
    Friend WithEvents uni2_4 As System.Windows.Forms.Button
    Friend WithEvents uni2_5 As System.Windows.Forms.Button
    Friend WithEvents uni2_6 As System.Windows.Forms.Button
    Friend WithEvents uni2_7 As System.Windows.Forms.Button
    Friend WithEvents uni2_8 As System.Windows.Forms.Button
    Friend WithEvents uni3_1 As System.Windows.Forms.Button
    Friend WithEvents uni3_2 As System.Windows.Forms.Button
    Friend WithEvents uni3_3 As System.Windows.Forms.Button
    Friend WithEvents uni3_4 As System.Windows.Forms.Button
    Friend WithEvents uni3_5 As System.Windows.Forms.Button
    Friend WithEvents uni3_6 As System.Windows.Forms.Button
    Friend WithEvents uni3_7 As System.Windows.Forms.Button
    Friend WithEvents uni3_8 As System.Windows.Forms.Button
    Friend WithEvents uni4_1 As System.Windows.Forms.Button
    Friend WithEvents uni4_2 As System.Windows.Forms.Button
    Friend WithEvents uni4_3 As System.Windows.Forms.Button
    Friend WithEvents uni4_4 As System.Windows.Forms.Button
    Friend WithEvents uni4_5 As System.Windows.Forms.Button
    Friend WithEvents uni4_6 As System.Windows.Forms.Button
    Friend WithEvents uni4_7 As System.Windows.Forms.Button
    Friend WithEvents uni4_8 As System.Windows.Forms.Button
    Friend WithEvents uni5_1 As System.Windows.Forms.Button
    Friend WithEvents uni5_2 As System.Windows.Forms.Button
    Friend WithEvents uni5_3 As System.Windows.Forms.Button
    Friend WithEvents uni5_4 As System.Windows.Forms.Button
    Friend WithEvents uni5_5 As System.Windows.Forms.Button
    Friend WithEvents uni5_6 As System.Windows.Forms.Button
    Friend WithEvents uni5_7 As System.Windows.Forms.Button
    Friend WithEvents uni5_8 As System.Windows.Forms.Button
    Friend WithEvents uni6_1 As System.Windows.Forms.Button
    Friend WithEvents uni6_2 As System.Windows.Forms.Button
    Friend WithEvents uni6_3 As System.Windows.Forms.Button
    Friend WithEvents uni6_4 As System.Windows.Forms.Button
    Friend WithEvents uni6_5 As System.Windows.Forms.Button
    Friend WithEvents uni6_6 As System.Windows.Forms.Button
    Friend WithEvents uni6_7 As System.Windows.Forms.Button
    Friend WithEvents uni6_8 As System.Windows.Forms.Button
    Friend WithEvents uni7_1 As System.Windows.Forms.Button
    Friend WithEvents uni7_2 As System.Windows.Forms.Button
    Friend WithEvents uni7_3 As System.Windows.Forms.Button
    Friend WithEvents uni7_4 As System.Windows.Forms.Button
    Friend WithEvents uni7_5 As System.Windows.Forms.Button
    Friend WithEvents uni7_6 As System.Windows.Forms.Button
    Friend WithEvents uni7_7 As System.Windows.Forms.Button
    Friend WithEvents uni8_1 As System.Windows.Forms.Button
    Friend WithEvents uni8_2 As System.Windows.Forms.Button
    Friend WithEvents uni8_3 As System.Windows.Forms.Button
    Friend WithEvents uni8_4 As System.Windows.Forms.Button
    Friend WithEvents uni8_5 As System.Windows.Forms.Button
    Friend WithEvents uni8_6 As System.Windows.Forms.Button
    Friend WithEvents uni8_7 As System.Windows.Forms.Button
    Friend WithEvents uni8_8 As System.Windows.Forms.Button
    Friend WithEvents uni7_8 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbEditmode As System.Windows.Forms.RadioButton
    Friend WithEvents rbPlaymode As System.Windows.Forms.RadioButton
    Friend WithEvents menuMainProj As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TestNReleaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutoPlayBetaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PushToDeviceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents groupUniPackInfo As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbPackAuthor As System.Windows.Forms.TextBox
    Friend WithEvents tbPackDirInfo As System.Windows.Forms.TextBox
    Friend WithEvents tbPackName As System.Windows.Forms.TextBox
    Friend WithEvents OpenProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SoundsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnSavePackInfo As System.Windows.Forms.Button
    Friend WithEvents tbPackChains As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents listChain As System.Windows.Forms.ListBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents labelInfSave As System.Windows.Forms.Label
    Friend WithEvents saveAnothername As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents SettingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents rblededit As System.Windows.Forms.RadioButton
    Friend WithEvents btnFlushLEDColor As System.Windows.Forms.Button
    Friend WithEvents btnFlushSound As System.Windows.Forms.Button
    Friend WithEvents AutoPlayControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OpenSettingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestoreDefaultWindowSizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ofdOpenAgain As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Mp3ToWavConverterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SoundCutterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KeySoundTextEditorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutoPlayTextEditorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TestMakeCrashToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents UploadToUniPackWWToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ledisableenable As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConnectMidiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
